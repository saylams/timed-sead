"""Independent feasibility check of a strike plan and a suppression schedule (step 4).

Written apart from the models, from the rules in model/step1_problem_statement.md
and model/formulation.tex, so that it can confirm a solution of any model or of the
ALNS. Returns a list of violations (empty if the solution is feasible).

    check_solution(inst, plan, windows)
        plan:    {striker: {"arcs": [arc dicts], "times": {node: time}}}
        windows: [(slot or label, asset id, start, end), ...]
    snap_solution(inst, plan, windows)
        the same solution read at whole minutes, for checking a solver's solution
Python 3.9 compatible.
"""
import sead_instance as SI

EPS = 1e-6
SNAP = 1e-3        # minutes: a time this close to a whole minute is read as that minute


def snap_solution(inst, plan, windows, tol=SNAP):
    """Solution read at whole minutes (2026-11-25). Returns (plan, windows).

    All instance data are whole minutes. A solver accepts a binary within its integrality
    tolerance (Gurobi 1e-5) of 0 or 1, so a window opened by a binary at 1 - 1e-5 is shorter
    by its length times 1e-5, and a hold may come out slightly below 0. Here every time within
    tol of a whole minute is rounded to it, and every window ends exactly one window length
    after its start. Times farther from a whole minute are kept as they are. The checker is
    then run on the result with its own tolerance EPS."""
    V = {v["id"]: v for v in inst["suppressors"]}

    def sn(x):
        x = float(x)
        return float(round(x)) if abs(x - round(x)) <= tol else x

    p2 = {r: dict(p, times={n: sn(t) for n, t in p["times"].items()}) for r, p in plan.items()}
    w2 = []
    for (lab, vid, s0, e0) in windows:
        a = sn(s0)
        w2.append((lab, vid, a, a + float(V[vid]["window"])))
    return p2, w2


def check_solution(inst, plan, windows):
    bad = []
    T = {t["id"]: t for t in inst["targets"]}
    Rd = {r["id"]: r for r in inst["strikers"]}
    V = {v["id"]: v for v in inst["suppressors"]}
    seen = {}
    # strikers: route continuity, travel times, weapons, endurance, time windows, one attack per target
    for r, p in plan.items():
        arcs, t = p["arcs"], p["times"]
        if arcs[0]["tail"] != "o_" + r or arcs[-1]["head"] != "d_" + r:
            bad.append("%s: route does not start and end at its base" % r)
        for a, b in zip(arcs[:-1], arcs[1:]):
            if a["head"] != b["tail"]:
                bad.append("%s: route broken at %s" % (r, a["head"]))
        for a in arcs:
            if r not in a["strikers"]:
                bad.append("%s: arc %s not allowed" % (r, a["id"]))
            if t[a["head"]] < t[a["tail"]] + a["time"] - EPS:
                bad.append("%s: arc %s flown faster than its time" % (r, a["id"]))
        visits = [a["head"] for a in arcs if a["head"] in T]
        if sum(T[m]["weapons"] for m in visits) > Rd[r]["weapons"]:
            bad.append("%s: more weapons than carried" % r)
        if t["d_" + r] - t["o_" + r] > Rd[r]["endurance"] + EPS:
            bad.append("%s: endurance exceeded" % r)
        if t["o_" + r] < -EPS:
            bad.append("%s: launch before time 0" % r)
        for m in visits:
            if not (T[m]["tw"][0] - EPS <= t[m] <= T[m]["tw"][1] + EPS):
                bad.append("%s: attack on %s outside its time window" % (r, m))
            seen[m] = seen.get(m, 0) + 1
    for m, c in seen.items():
        if c > 1:
            bad.append("target %s attacked %d times" % (m, c))
    # suppressors: window length, reachability, endurance, expendables at most one window
    site_of_win = {}
    by_asset = {}
    for (lab, vid, s0, e0) in windows:
        by_asset.setdefault(vid, []).append((s0, e0, lab))
    for vid, ws in by_asset.items():
        v = V[vid]
        t0, tb, tss = SI.supp_tau(inst, v)
        ws.sort()
        sites = []
        for (s0, e0, lab) in ws:
            site = lab if lab in t0 else lab.split("_")[0]
            sites.append(site)
            site_of_win[(vid, s0, e0)] = site
            if site not in v["sites"]:
                bad.append("%s cannot suppress %s" % (vid, site))
            if abs((e0 - s0) - float(v["window"])) > EPS:
                bad.append("%s: window at %s has the wrong length" % (vid, site))
        if v["expendable"] and len(ws) > 1:
            bad.append("%s is expendable but opens %d windows" % (vid, len(ws)))
        if ws[0][0] < t0[sites[0]] - EPS:
            bad.append("%s: first window opens before the asset can arrive" % vid)
        for n in range(1, len(ws)):
            need = ws[n - 1][1] + tss.get((sites[n - 1], sites[n]), 0.0)
            if ws[n][0] < need - EPS:
                bad.append("%s: window %d opens before the asset can arrive from the previous one" % (vid, n + 1))
        launch = ws[0][0] - t0[sites[0]]                  # latest possible launch
        end = ws[-1][1] + (0.0 if v["expendable"] else tb[sites[-1]])
        if end - launch > v["endurance"] + EPS:
            bad.append("%s: endurance exceeded" % vid)
    # coupling: every zone stay inside one window at its site
    stays = SI.stays_from_plan(inst, plan)
    for h in stays:
        ok = any(site_of_win[(vid, s0, e0)] == h["site"] and s0 <= h["start"] + EPS and e0 >= h["end"] - EPS
                 for (vid, s0, e0) in site_of_win)
        if not ok:
            bad.append("stay of %s in zone %s from %.2f to %.2f is not covered by one window"
                       % (h["striker"], h["site"], h["start"], h["end"]))
    return bad
