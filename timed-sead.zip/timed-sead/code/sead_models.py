"""Gurobi models for the timed-SEAD papers (step 4).

    build_paper_A(inst, version, ...)   integrated model and its versions (Paper A)
    build_paper_B_slot(inst, plan, ...) Paper B, continuous time with task slots
    build_paper_B_ti(inst, plan, ...)   Paper B, time-indexed (time-space network)

Each builder returns a dict with the gurobipy model under "model" and the
variables needed to read the solution. Equation labels in the comments refer to
model/formulation.tex. Python 3.9 compatible.

Settings of the continuous models (formulation.tex Section 6):
    tight  smallest valid constant in each conditional constraint (else H)
    sym    slot symmetry (open in order, start in order)
    vi     window-length inequalities
"""
import time

import gurobipy as gp
from gurobipy import GRB

from sead_instance import (build_arcs, node_bounds, inside_sites, supp_tau, slots,
                           stays_from_plan, route_nodes)

H_LOOSE = 200.0          # loose constant, used when tight=False (at least H_bar + 50, see h_loose)


def h_loose(inst):
    """Loose constant of the untightened models: H_bar + 50, as in step 3 (200 for H_bar 150).
    Instance-dependent since 2026-11-24, when the lead widened H_bar beyond 150."""
    return max(H_LOOSE, float(inst["H_bar"]) + 50.0)


def _pos(x):
    return max(0.0, float(x))


def _params(m, time_limit=None, threads=None, mip_gap=None, output=0):
    m.Params.OutputFlag = output
    if time_limit is not None:
        m.Params.TimeLimit = time_limit
    if threads is not None:
        m.Params.Threads = threads
    if mip_gap is not None:
        m.Params.MIPGap = mip_gap


# ------------------------------------------------------------------ Block C
def _block_C(m, inst, supp, K, site_of, SB, sym, link=False, noback=False):
    """Routing and timing of suppressors (C-flow to C-exp). Returns rho, z, u, sig, phi.

    link: add rho_vk <= z_v (an asset serves a slot only if it is used), valid for every
    integer solution and much stronger in the linear relaxation (2026-11-24).
    noback: with slot symmetry, no move from a later slot to an earlier slot of the same site
    (its start would precede the start of the later slot), so these arcs are not created."""
    sig = {k: m.addVar(lb=SB[k][0], ub=SB[k][1], name="sig_" + k) for k in site_of}
    phi = {k: m.addVar(lb=SB[k][2], ub=SB[k][3], name="phi_" + k) for k in site_of}
    th_ub = max(SB[k][1] for k in SB)
    g_ub = max(SB[k][3] for k in SB) + 1000.0
    u, rho_terms, z = {}, {}, {}
    for v in supp:
        vid = v["id"]
        t0, tb, tss = supp_tau(inst, v)
        Kv = [k for s in v["sites"] for k in K[s]]
        theta = m.addVar(lb=0.0, ub=th_ub, name="theta_" + vid)
        g = m.addVar(lb=0.0, ub=g_ub, name="g_" + vid)
        for k in Kv:
            u[(vid, "0", k)] = m.addVar(vtype=GRB.BINARY, name="u_%s_0_%s" % (vid, k))
            u[(vid, k, "E")] = m.addVar(vtype=GRB.BINARY, name="u_%s_%s_E" % (vid, k))
            if not v["expendable"]:
                for k2 in Kv:
                    if k2 != k:
                        if sym and noback and site_of[k] == site_of[k2] and \
                                K[site_of[k]].index(k2) < K[site_of[k]].index(k):
                            continue
                        u[(vid, k, k2)] = m.addVar(vtype=GRB.BINARY, name="u_%s_%s_%s" % (vid, k, k2))
        for k in Kv:
            rho_terms[(vid, k)] = [u[key] for key in u if key[0] == vid and key[2] == k]
        z[vid] = gp.quicksum(u[(vid, "0", k)] for k in Kv)
        m.addConstr(z[vid] <= 1, name="Cflow0_" + vid)                                       # (C-flow)
        if link:                                                                               # (C-link)
            for k in Kv:
                m.addConstr(gp.quicksum(rho_terms[(vid, k)]) <= z[vid], name="Clink_%s_%s" % (vid, k))
        for k in Kv:
            out_k = [u[key] for key in u if key[0] == vid and key[1] == k]
            m.addConstr(gp.quicksum(rho_terms[(vid, k)]) == gp.quicksum(out_k), name="Cflow_%s_%s" % (vid, k))
        for k in Kv:
            s = site_of[k]
            M1 = _pos(th_ub + t0[s] - SB[k][0])
            m.addConstr(sig[k] >= theta + t0[s] - M1 * (1 - u[(vid, "0", k)]), name="Cfirst_%s_%s" % (vid, k))  # (C-first)
            if not v["expendable"]:
                for k2 in Kv:
                    if k2 != k and (vid, k, k2) in u:
                        tt = tss.get((s, site_of[k2]), 0.0)
                        M2 = _pos(SB[k][3] + tt - SB[k2][0])
                        m.addConstr(sig[k2] >= phi[k] + tt - M2 * (1 - u[(vid, k, k2)]),
                                    name="Cnext_%s_%s_%s" % (vid, k, k2))                         # (C-next)
                M3 = _pos(SB[k][3] + tb[s])
                m.addConstr(g >= phi[k] + tb[s] - M3 * (1 - u[(vid, k, "E")]), name="Cback_%s_%s" % (vid, k))  # (C-back)
            else:
                M4 = _pos(SB[k][3] - v["endurance"])
                m.addConstr(phi[k] - theta <= v["endurance"] + M4 * (1 - gp.quicksum(rho_terms[(vid, k)])),
                            name="Cexp_%s_%s" % (vid, k))                                          # (C-exp)
        if not v["expendable"]:
            m.addConstr(g - theta <= v["endurance"], name="Cend_" + vid)                       # (C-back)
    L = {v["id"]: float(v["window"]) for v in supp}
    for k in site_of:
        users = [(vid, x) for (vid, kk), xs in rho_terms.items() if kk == k for x in xs]
        m.addConstr(gp.quicksum(x for _, x in users) <= 1, name="Conce_" + k)                 # (C-once)
        m.addConstr(phi[k] == sig[k] + gp.quicksum(L[vid] * x for vid, x in users), name="Clen_" + k)  # (C-len)
    if sym:                                                                                    # (sym)
        for s, ks in K.items():
            for k1, k2 in zip(ks[:-1], ks[1:]):
                r1 = gp.quicksum(x for (vid, kk), xs in rho_terms.items() if kk == k1 for x in xs)
                r2 = gp.quicksum(x for (vid, kk), xs in rho_terms.items() if kk == k2 for x in xs)
                m.addConstr(r2 <= r1, name="symopen_" + k2)
                m.addConstr(sig[k1] <= sig[k2], name="symstart_" + k2)
    return rho_terms, z, u, sig, phi


def useful_bound_valid(inst, supp):
    """True if dropping a window that covers no stay can never make a plan infeasible: for every
    reusable asset, flying a to c directly is no slower than a to b, the window at b and b to c
    (a, b, c among its base and sites). Then every opened window may be assumed to cover a stay."""
    for v in supp:
        if v["expendable"]:
            continue                      # dropping a decoy's only window means not using the decoy
        t0, tb, tss = supp_tau(inst, v)
        S = list(v["sites"])
        def tau(a, b):
            if a == b:
                return 0.0
            if a == "B":
                return t0[b]
            if b == "B":
                return tb[a]
            return tss.get((a, b), float("inf"))
        L = float(v["window"])
        P = ["B"] + S
        for a in P:
            for b in S:
                for c in P:
                    if a != b and b != c and tau(a, c) > tau(a, b) + L + tau(b, c) + 1e-9:
                        return False
    return True


def _slot_bounds(inst, supp, K, latest, need=None):
    """(ES sigma, LS sigma, ES phi, LS phi) per slot; ES phi = ES sigma (unopened slot).

    need: optional {site: earliest end of a stay there}. Since every opened window may be assumed
    to cover a stay (see useful_bound_valid), a window at s opens no earlier than need[s] minus the
    longest window at s (earliest useful window, 2026-11-24)."""
    SB = {}
    for s, ks in K.items():
        able = [supp_tau(inst, v)[0][s] for v in supp if s in v["sites"]]
        es = min(able) if able else 0.0
        if need and s in need:
            Lm = max([float(v["window"]) for v in supp if s in v["sites"]] or [0.0])
            es = max(es, need[s] - Lm)
        ls = max(es, latest.get(s, 0.0))
        Lmax = max([float(v["window"]) for v in supp if s in v["sites"]] or [0.0])
        for k in ks:
            SB[k] = (es, ls, es, ls + Lmax)
    return SB


def _rho_sum(rho_terms, k, ok=None):
    return gp.quicksum(x for (vid, kk), xs in rho_terms.items()
                       if kk == k and (ok is None or vid in ok) for x in xs)


# ------------------------------------------------------------------ Paper A
def build_paper_A(inst, version="integrated", tight=True, sym=True, vi=True, **par):
    """version: 'integrated', 'A' (zones removed), 'free' (zones ignored), 'no_drones'."""
    m = gp.Model("paperA_" + version)
    HL = h_loose(inst)
    _params(m, **par)
    R = [r["id"] for r in inst["strikers"]]
    Rd = {r["id"]: r for r in inst["strikers"]}
    T = {t["id"]: t for t in inst["targets"]}
    ins = inside_sites(inst)
    arcs = build_arcs(inst)
    if version == "A":
        arcs = [a for a in arcs if not a["segs"] and a["tail"] not in ins and a["head"] not in ins]
    nodes = list(T) + ["o_" + r for r in R] + ["d_" + r for r in R]
    if tight:
        ES, LS = node_bounds(inst)
        HB = float(inst["H_bar"])
    else:
        ES = {i: 0.0 for i in nodes}
        LS = {i: HL for i in nodes}
        HB = float(inst["H_bar"])     # the mission ends by H_bar in every version (2026-11-24), so loose
                                      # and tight models have the same feasible set and differ only in constants
    x = {(r, a["id"]): m.addVar(vtype=GRB.BINARY, name="x_%s_%s" % (r, a["id"])) for a in arcs for r in a["strikers"]}
    y = {i: m.addVar(vtype=GRB.BINARY, name="y_" + i) for i in T}
    t = {i: m.addVar(lb=ES[i], ub=LS[i], name="t_" + i) for i in nodes}
    Tmax = m.addVar(lb=0.0, ub=HB, name="Tmax")
    xa = lambda a: gp.quicksum(x[(r, a["id"])] for r in a["strikers"])
    inA = {i: [a for a in arcs if a["head"] == i] for i in nodes}
    outA = {i: [a for a in arcs if a["tail"] == i] for i in nodes}
    # Block A
    for r in R:
        m.addConstr(gp.quicksum(x[(r, a["id"])] for a in outA["o_" + r] if r in a["strikers"]) == 1, name="Abase_o_" + r)
        m.addConstr(gp.quicksum(x[(r, a["id"])] for a in inA["d_" + r] if r in a["strikers"]) == 1, name="Abase_d_" + r)
        for i in T:
            m.addConstr(gp.quicksum(x[(r, a["id"])] for a in inA[i] if r in a["strikers"]) ==
                        gp.quicksum(x[(r, a["id"])] for a in outA[i] if r in a["strikers"]), name="Aflow_%s_%s" % (r, i))
        m.addConstr(gp.quicksum(T[a["head"]]["weapons"] * x[(r, a["id"])] for i in T for a in inA[i] if r in a["strikers"])
                    <= Rd[r]["weapons"], name="Acap_" + r)
    for i in T:
        m.addConstr(y[i] == gp.quicksum(xa(a) for a in inA[i]), name="Avisit_" + i)
    # Block B
    for a in arcs:
        Ma = _pos(LS[a["tail"]] - ES[a["head"]]) if tight else HL
        m.addConstr(t[a["head"]] >= t[a["tail"]] + a["time"] * xa(a) - Ma * (1 - xa(a)), name="Bprop_" + a["id"])  # (B-prop)
    if not tight:
        for i in T:                                                                            # (B-tw)
            m.addConstr(t[i] >= T[i]["tw"][0] * y[i], name="Btwl_" + i)
            m.addConstr(t[i] <= T[i]["tw"][1] + HL * (1 - y[i]), name="Btwu_" + i)
    for r in R:                                                                                # (B-end)
        m.addConstr(t["d_" + r] - t["o_" + r] <= Rd[r]["endurance"], name="Bend_" + r)
        m.addConstr(Tmax >= t["d_" + r], name="Bmax_" + r)
    out = {"model": m, "inst": inst, "version": version, "arcs": arcs, "x": x, "y": y, "t": t, "Tmax": Tmax}
    obj = gp.quicksum(T[i]["value"] * y[i] for i in T) - inst["mu"] * Tmax
    if version in ("A", "free"):
        m.setObjective(obj, GRB.MAXIMIZE)
        return out
    supp = [v for v in inst["suppressors"] if version != "no_drones" or v.get("manned", False)]
    K, site_of = slots(inst)
    latest = {}
    for a in arcs:
        for (s, al, be) in a["segs"]:
            latest[s] = max(latest.get(s, 0.0), LS[a["tail"]] + al)
    SB = _slot_bounds(inst, supp, K, latest) if tight else {k: (0.0, HL, 0.0, HL) for k in site_of}
    rho_terms, z, u, sig, phi = _block_C(m, inst, supp, K, site_of, SB, sym)
    obj = obj - gp.quicksum(v["cost"] * z[v["id"]] for v in supp)
    L = {v["id"]: float(v["window"]) for v in supp}
    # Block D
    w = {}
    for a in arcs:
        for (s, al, be) in a["segs"]:
            for k in K[s]:
                w[(a["id"], k)] = m.addVar(vtype=GRB.BINARY, name="w_%s_%s" % (a["id"], k))
            m.addConstr(gp.quicksum(w[(a["id"], k)] for k in K[s]) == xa(a), name="Dcover_%s_%s" % (a["id"], s))  # (D-cover)
            ok = [vid for vid in L if (not vi) or L[vid] >= be - al]                            # (VI-arc)
            for k in K[s]:
                wk = w[(a["id"], k)]
                m.addConstr(wk <= _rho_sum(rho_terms, k, ok), name="Dactive_%s_%s" % (a["id"], k))  # (D-active)
                MS = _pos(SB[k][1] - ES[a["tail"]]) if tight else HL
                ME = _pos(LS[a["tail"]] + be - SB[k][2]) if tight else HL
                m.addConstr(sig[k] <= t[a["tail"]] + al * xa(a) + MS * (1 - wk), name="Dstart_%s_%s" % (a["id"], k))  # (D-start)
                m.addConstr(phi[k] >= t[a["tail"]] + be * xa(a) - ME * (1 - wk), name="Dend_%s_%s" % (a["id"], k))    # (D-end)
    om = {}
    for s in inst["sites"]:
        sid = s["id"]
        for i in s["inside"]:
            for k in K[sid]:
                om[(i, k)] = m.addVar(vtype=GRB.BINARY, name="om_%s_%s" % (i, k))
            m.addConstr(gp.quicksum(om[(i, k)] for k in K[sid]) == y[i], name="Dnode_" + i)     # (D-node)
            seg = lambda a: [g for g in a["segs"] if g[0] == sid]
            for a in inA[i] + outA[i]:
                if not seg(a):
                    continue
                for k in K[sid]:
                    m.addConstr(w[(a["id"], k)] >= om[(i, k)] + xa(a) - 1, name="Dsame_%s_%s" % (a["id"], k))  # (D-same)
            if vi:
                lin = [a["time"] - seg(a)[0][1] for a in inA[i] if seg(a)]
                lout = [seg(a)[0][2] for a in outA[i] if seg(a)]
                if lin and lout:
                    ell = min(lin) + min(lout)
                    ok = [vid for vid in L if L[vid] >= ell]
                    for k in K[sid]:
                        m.addConstr(om[(i, k)] <= _rho_sum(rho_terms, k, ok), name="VInode_%s_%s" % (i, k))  # (VI-node)
    m.setObjective(obj, GRB.MAXIMIZE)
    out.update({"supp": supp, "u": u, "sig": sig, "phi": phi, "w": w, "z": z, "rho_terms": rho_terms, "slots": K})
    return out


# ------------------------------------------------------------------ reading solutions
def plan_from_A(res):
    """Routes and times of the strikers from a solved Paper A model."""
    inst, x, t = res["inst"], res["x"], res["t"]
    plan = {}
    for r in [s["id"] for s in inst["strikers"]]:
        used = [a for a in res["arcs"] if r in a["strikers"] and x[(r, a["id"])].X > 0.5]
        node, seq = "o_" + r, []
        while node != "d_" + r:
            a = [b for b in used if b["tail"] == node][0]
            seq.append(a)
            node = a["head"]
        times = {n: t[n].X for n in route_nodes({"arcs": seq})}
        plan[r] = {"arcs": seq, "times": times}
    return plan


def windows_from(res):
    """Opened windows: list of (slot, asset, start, end), from a slot model."""
    outw = []
    for k, sv in res["sig"].items():
        for (vid, kk), xs in res["rho_terms"].items():
            if kk == k and sum(xv.X for xv in xs) > 0.5:
                outw.append((k, vid, sv.X, res["phi"][k].X))
    return sorted(outw, key=lambda w: (w[1], w[2]))


def summary(res, t0=None):
    m = res["model"]
    st = {GRB.OPTIMAL: "optimal", GRB.INFEASIBLE: "infeasible", GRB.TIME_LIMIT: "time limit",
          GRB.INF_OR_UNBD: "infeasible or unbounded"}.get(m.Status, str(m.Status))
    d = {"status": st, "vars": m.NumVars, "constrs": m.NumConstrs, "runtime": m.Runtime}
    if m.SolCount > 0:
        d.update({"obj": m.ObjVal, "bound": m.ObjBound, "gap": m.MIPGap if m.IsMIP else 0.0})
    return d


# ------------------------------------------------------------------ Paper B, slots
def _holds(m, inst, plan, stays, delay):
    """Hold variables of the delay variant: at route nodes outside every zone (not the end)."""
    ins = inside_sites(inst)
    D = {}
    T = {t["id"]: t for t in inst["targets"]}
    Rd = {r["id"]: r for r in inst["strikers"]}
    for r, p in plan.items():
        nodes = route_nodes(p)
        for j, n in enumerate(nodes[:-1]):
            if n not in ins:
                D[(r, j)] = m.addVar(lb=0.0, ub=delay, name="D_%s_%d" % (r, j))
        m.addConstr(gp.quicksum(D[(rr, j)] for (rr, j) in D if rr == r) <= delay, name="Dmax_" + r)
        for j, n in enumerate(nodes):                                       # shifted attack times stay in windows
            if n in T:
                m.addConstr(p["times"][n] + gp.quicksum(D[(rr, jj)] for (rr, jj) in D if rr == r and jj <= j)
                            <= T[n]["tw"][1], name="Dtw_%s_%d" % (r, j))
        dur = p["times"][nodes[-1]] - p["times"][nodes[0]]                   # holds after launch use endurance
        m.addConstr(dur + gp.quicksum(D[(rr, jj)] for (rr, jj) in D if rr == r and jj >= 1)
                    <= Rd[r]["endurance"], name="Dend_" + r)
    shift = lambda h: gp.quicksum(D[(rr, jj)] for (rr, jj) in D if rr == h["striker"] and jj <= h["leg"])
    return D, shift


def build_paper_B_slot(inst, plan, select=False, delay=None, tight=True, sym=True, vi=True,
                       useful=False, link=False, trim=False, noback=False, **par):
    """Paper B, continuous time with task slots (formulation.tex Section 5).

    select: sortie-selection version (cancel whole sorties, maximise supported value).
    delay:  None, or the bound on the total hold of each striker (delay variant)."""
    m = gp.Model("paperB_slot")
    HL = h_loose(inst)
    _params(m, **par)
    stays = stays_from_plan(inst, plan)
    supp = inst["suppressors"]
    K, site_of = slots(inst)
    drop_ok = useful_bound_valid(inst, supp) if (useful or trim) else False
    if trim and drop_ok:                                                                       # (trim)
        # every opened window may be assumed to cover a stay, so a site needs no more windows
        # than it has stays (2026-11-24)
        n_at = {}
        for h in stays:
            n_at[h["site"]] = n_at.get(h["site"], 0) + 1
        K = {s: ["%s_k%d" % (s, n) for n in range(n_at.get(s, 0))] for s in K}
        site_of = {k: s for s, ks in K.items() for k in ks}
    dmax = float(delay) if delay is not None else 0.0
    latest = {}
    for h in stays:
        latest[h["site"]] = max(latest.get(h["site"], 0.0), h["start"] + dmax)
    need = None
    if tight and useful and drop_ok:
        need = {}
        for h in stays:
            need[h["site"]] = min(need.get(h["site"], float("inf")), h["end"])
    SB = _slot_bounds(inst, supp, K, latest, need) if tight else {k: (0.0, HL, 0.0, HL) for k in site_of}
    rho_terms, z, u, sig, phi = _block_C(m, inst, supp, K, site_of, SB, sym, link, noback)
    L = {v["id"]: float(v["window"]) for v in supp}
    D, shift = _holds(m, inst, plan, stays, delay) if delay is not None else ({}, lambda h: 0.0)
    kappa = {}
    cost = gp.quicksum(v["cost"] * z[v["id"]] for v in supp)
    if select:
        T = {t["id"]: t for t in inst["targets"]}
        val = {r: sum(T[a["head"]]["value"] for a in p["arcs"] if a["head"] in T) for r, p in plan.items()}
        kappa = {r: m.addVar(vtype=GRB.BINARY, name="kappa_" + r) for r in plan}
    w = {}
    for n, h in enumerate(stays):
        s = h["site"]
        for k in K[s]:
            w[(n, k)] = m.addVar(vtype=GRB.BINARY, name="w_%d_%s" % (n, k))
        rhs = kappa[h["striker"]] if select else 1
        m.addConstr(gp.quicksum(w[(n, k)] for k in K[s]) == rhs, name="Bcover_%d" % n)          # (B-cover)
        ok = [vid for vid in L if (not vi) or L[vid] >= h["end"] - h["start"]]                  # (VI-stay)
        for k in K[s]:
            MS = _pos(SB[k][1] - h["start"]) if tight else HL
            ME = _pos(h["end"] + dmax - SB[k][2]) if tight else HL
            m.addConstr(w[(n, k)] <= _rho_sum(rho_terms, k, ok), name="Bactive_%d_%s" % (n, k))
            m.addConstr(sig[k] <= h["start"] + shift(h) + MS * (1 - w[(n, k)]), name="Bstart_%d_%s" % (n, k))  # (B-window)
            m.addConstr(phi[k] >= h["end"] + shift(h) - ME * (1 - w[(n, k)]), name="Bend_%d_%s" % (n, k))
    holdcost = inst["mu"] * gp.quicksum(D.values()) if D else 0.0
    if select:
        m.setObjective(gp.quicksum(val[r] * kappa[r] for r in plan) - cost - holdcost, GRB.MAXIMIZE)
    else:
        m.setObjective(cost + holdcost, GRB.MINIMIZE)
    return {"model": m, "inst": inst, "stays": stays, "kappa": kappa, "D": D, "sig": sig, "phi": phi,
            "rho_terms": rho_terms, "z": z, "w": w}


# ------------------------------------------------------------------ Paper B, time-indexed
def build_paper_B_ti(inst, plan, select=False, delay=None, Q=None, **par):
    """Paper B, time-indexed formulation on a 1-minute grid (formulation.tex Section 5).

    Stays are widened to the grid (start rounded down, end rounded up)."""
    import math
    m = gp.Model("paperB_ti")
    _params(m, **par)
    stays = stays_from_plan(inst, plan)
    supp = inst["suppressors"]
    dmax = int(delay) if delay is not None else 0
    if Q is None:
        Q = int(math.ceil(max([h["end"] for h in stays] or [0.0]))) + dmax + \
            int(max(float(v["window"]) for v in supp)) + 1
    f, win, skip = {}, {}, {}
    for v in supp:
        vid, Lv = v["id"], int(round(float(v["window"])))
        t0, tb, tss = supp_tau(inst, v)
        A = [("skip", "src", "snk", 0.0)]
        for s in v["sites"]:
            a0 = int(math.ceil(t0[s]))
            for q in range(a0, Q + 1):
                A.append(("L_%s_%d" % (s, q), "src", (s, q), t0[s]))
                if q + 1 <= Q:
                    A.append(("W_%s_%d" % (s, q), (s, q), (s, q + 1), 1.0))
                if q + Lv <= Q:
                    A.append(("X_%s_%d" % (s, q), (s, q), "snk" if v["expendable"] else (s, q + Lv), float(Lv)))
                if not v["expendable"]:
                    for s2 in v["sites"]:
                        if s2 != s and (s, s2) in tss and q + int(math.ceil(tss[(s, s2)])) <= Q:
                            A.append(("T_%s_%s_%d" % (s, s2, q), (s, q), (s2, q + int(math.ceil(tss[(s, s2)]))), tss[(s, s2)]))
                    A.append(("R_%s_%d" % (s, q), (s, q), "snk", tb[s]))
        for (nm, a, b, d) in A:
            f[(vid, nm)] = m.addVar(vtype=GRB.BINARY, name="f_%s_%s" % (vid, nm))
        for (nm, a, b, d) in A:
            if nm.startswith("X_"):
                _, s, q = nm.split("_")
                win[(vid, s, int(q))] = f[(vid, nm)]
        skip[vid] = f[(vid, "skip")]
        nodes = set([a for (_, a, _, _) in A] + [b for (_, _, b, _) in A])
        for n in nodes:                                                                      # (TI-flow)
            bal = gp.quicksum(f[(vid, nm)] for (nm, a, b, d) in A if a == n) - \
                  gp.quicksum(f[(vid, nm)] for (nm, a, b, d) in A if b == n)
            m.addConstr(bal == (1 if n == "src" else (-1 if n == "snk" else 0)), name="TIflow_%s_%s" % (vid, str(n)))
        m.addConstr(gp.quicksum(d * f[(vid, nm)] for (nm, a, b, d) in A) <= v["endurance"], name="TIend_" + vid)  # (TI-end)
    L = {v["id"]: int(round(float(v["window"]))) for v in supp}
    cost = gp.quicksum(v["cost"] * (1 - skip[v["id"]]) for v in supp)
    kappa, D, pi = {}, {}, {}
    if select:
        T = {t["id"]: t for t in inst["targets"]}
        val = {r: sum(T[a["head"]]["value"] for a in p["arcs"] if a["head"] in T) for r, p in plan.items()}
        kappa = {r: m.addVar(vtype=GRB.BINARY, name="kappa_" + r) for r in plan}
    if delay is not None:
        D, shift = _holds(m, inst, plan, stays, delay)
    for n, h in enumerate(stays):
        b, e, s = int(math.floor(h["start"] + 1e-9)), int(math.ceil(h["end"] - 1e-9)), h["site"]
        rhs = kappa[h["striker"]] if select else 1
        if delay is None:
            cov = gp.quicksum(xv for (vid, ss, q), xv in win.items() if ss == s and q <= b and q + L[vid] >= e)
            m.addConstr(cov >= rhs, name="TIcover_%d" % n)                                       # (TI-cover)
        else:
            for d in range(dmax + 1):
                pi[(n, d)] = m.addVar(vtype=GRB.BINARY, name="pi_%d_%d" % (n, d))
                cov = gp.quicksum(xv for (vid, ss, q), xv in win.items() if ss == s and q <= b + d and q + L[vid] >= e + d)
                m.addConstr(cov >= pi[(n, d)], name="TIcover_%d_%d" % (n, d))
            m.addConstr(gp.quicksum(pi[(n, d)] for d in range(dmax + 1)) == rhs, name="TIpick_%d" % n)
            m.addConstr(gp.quicksum(d * pi[(n, d)] for d in range(dmax + 1)) == shift(h), name="TIshift_%d" % n)
    holdcost = inst["mu"] * gp.quicksum(D.values()) if D else 0.0
    if select:
        m.setObjective(gp.quicksum(val[r] * kappa[r] for r in plan) - cost - holdcost, GRB.MAXIMIZE)
    else:
        m.setObjective(cost + holdcost, GRB.MINIMIZE)
    return {"model": m, "inst": inst, "stays": stays, "kappa": kappa, "D": D, "win": win, "skip": skip, "Q": Q}
