"""Step 5 experiments: resumable runs, one JSON file per run.

Settings decided by Serhat on 2026-11-23: every exact run with a 600 s time limit,
8 threads and MIP gap 0. The Paper B set runs first.

Paper B set (this module, run from code/step5_paperB.ipynb):
    75 instances x 2 models (slot, ti) x 5 variants
    (fixed, select, delay5, delay10, delay15) = 750 runs. Since 2026-11-24 the instances
    have strikers launching at H-hour (lead) and two fleet levels (base, and x2 or x3 for
    4 and 6 strikers, names ending -x2 and -x3). The first set of 45 instances and its
    450 runs are kept in instances/_superseded_v1/ and results/step5/_superseded_v1/.
    slot: continuous time with task slots, tight constants, slot symmetry and
          window-length inequalities (formulation.tex Sections 5 and 6), strengthened on
          2026-11-24 with one slot per stay, the earliest useful window, the asset-use link
          and no moves back to an earlier slot (SLOT_B below)
    ti:   time-indexed formulation on a 1-minute grid (formulation.tex Section 5)

Every run: build the model, solve it, solve the LP relaxation of the same model,
read the solution back, confirm it with the independent checker sead_check.py, and
save results/step5/paperB/<instance>__<model>__<variant>.json. The Gurobi log of
each run goes to results/step5/paperB/logs/. Runs already saved are skipped, so the
notebook can be stopped and restarted at any time. A run that ended in an error is
saved with status "error" and is tried again at the next start.

Paper A exact set (added 2026-11-24, run from code/step5_paperA.ipynb): 60 instances with
4 to 10 targets x 10 runs (full, A, free, seq_fixed, seq_delay15, no_drones, full_slots2,
tight_sym, tight, loose; see RUNS_A below) = 600 runs, saved in results/step5/paperA/, checked by
summarize_paperA(), which writes results/step5/paperA_runs.csv.

summarize_paperB() reads all saved runs, writes results/step5/paperB_runs.csv (one
line per run) and prints the consistency checks: solver status counts, checker
violations, slot against time-indexed optima, monotonicity in the delay bound, and
sites whose slots were all used (then the slot number must be raised).

Python 3.9 compatible.
"""
import csv
import glob
import json
import math
import os
import platform
import sys
import time
import traceback
from datetime import datetime

import gurobipy as gp
from gurobipy import GRB

import sead_check as SC
import sead_instance as SI
import sead_models as SM

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
INST_B = os.path.join(ROOT, "instances", "paperB")
OUT = os.path.join(ROOT, "results", "step5")
OUT_B = os.path.join(OUT, "paperB")

SETTINGS = {"time_limit": 600, "threads": 8, "mip_gap": 0.0}
DELAYS = (5, 10, 15)
TOL = 1e-6

STATUS = {GRB.OPTIMAL: "optimal", GRB.INFEASIBLE: "infeasible", GRB.TIME_LIMIT: "time limit",
          GRB.INF_OR_UNBD: "infeasible or unbounded"}
INTERRUPTED = getattr(GRB, "INTERRUPTED", 11)   # Gurobi returns this status on Kernel > Interrupt

# Strengthened continuous-time model (2026-11-24, formulation.tex Section 6): one slot per stay at
# each site (trim), earliest useful window (useful), rho_vk <= z_v (link), and no move back to an
# earlier slot of the same site (noback). The 36 slot runs made before this change are kept in
# results/step5/_superseded_slot_v2a/.
SLOT_B = {"trim": True, "useful": True, "link": True, "noback": True}


def build_slot_B(inst, plan, **kw):
    return SM.build_paper_B_slot(inst, plan, **dict(SLOT_B, **kw))


MODELS_B = (("slot", build_slot_B), ("ti", SM.build_paper_B_ti))
MODEL_OPTIONS = {"slot": SLOT_B, "ti": {}}


def variants_B():
    out = [("fixed", {}), ("select", {"select": True})]
    for d in DELAYS:
        out.append(("delay%d" % d, {"delay": d}))
    return out


# ------------------------------------------------------------------ small helpers
def _num(x):
    """JSON-safe number: None for missing, infinite or NaN values."""
    try:
        x = float(x)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def _attr(m, name):
    try:
        return getattr(m, name)
    except Exception:
        return None


def _dump(obj, path):
    """Write JSON through a temporary file, so a stopped run never leaves half a file.
    Retries for a few seconds if the file is briefly locked (Dropbox on Windows)."""
    tmp = path + ".tmp"
    for attempt in range(10):
        try:
            with open(tmp, "w") as f:
                json.dump(obj, f, indent=1)
            os.replace(tmp, path)
            return
        except (PermissionError, OSError):
            if attempt == 9:
                raise
            time.sleep(1.0)


def _load(path):
    with open(path) as f:
        return json.load(f)


def gurobi_version():
    try:
        return ".".join(str(v) for v in gp.gurobi.version())
    except Exception:
        return "unknown (" + getattr(gp, "__name__", "?") + ")"


def run_info():
    """Machine, solver and settings, stored once per notebook start."""
    return {"started": datetime.now().isoformat(timespec="seconds"), "gurobi": gurobi_version(),
            "python": sys.version.split()[0], "platform": platform.platform(),
            "processor": platform.processor(), "cpu_count": os.cpu_count(), "settings": SETTINGS}


def _instance_class(inst):
    p = inst.get("params", {})
    parts = inst["name"].split("_")
    mix = parts[3] if len(parts) > 3 else None          # e.g. 'mixed' or 'mixed-x2' (scaled fleet)
    return {"strikers": len(inst["strikers"]), "sites": len(inst["sites"]), "targets": len(inst["targets"]),
            "fleet_mix": mix.split("-x")[0] if mix else None, "fleet_scale": p.get("fleet_scale", 1),
            "lead": inst.get("lead", 0), "H_bar": inst.get("H_bar"), "fleet": p.get("fleet"),
            "suppressors": len(inst["suppressors"]), "seed": inst.get("seed"),
            "slots_per_site": inst.get("slots_per_site")}


def _solve_lp(m):
    """LP relaxation of a built model (same constraints, integrality dropped)."""
    try:
        r = m.relax()
        r.Params.OutputFlag = 0
        r.Params.Threads = SETTINGS["threads"]
        r.Params.TimeLimit = SETTINGS["time_limit"]
        t0 = time.time()
        r.optimize()
        if r.Status == INTERRUPTED:
            raise KeyboardInterrupt
        out = {"status": STATUS.get(r.Status, str(r.Status)), "runtime": time.time() - t0,
               "obj": _num(r.ObjVal) if r.Status == GRB.OPTIMAL else None}
        if hasattr(r, "dispose"):
            r.dispose()
        return out
    except Exception as e:
        return {"status": "error", "error": repr(e)}


def _use_log(m, log_path):
    """Gurobi log to a file only (nothing printed in the notebook)."""
    try:
        m.Params.LogToConsole = 0
        m.Params.LogFile = log_path
        m.Params.OutputFlag = 1
    except Exception:
        pass


# ------------------------------------------------------------------ Paper B solutions
def windows_ti(res):
    """Opened windows of the time-indexed model: (site, asset, start, end)."""
    L = {v["id"]: float(v["window"]) for v in res["inst"]["suppressors"]}
    out = [(s, vid, float(q), float(q) + L[vid]) for (vid, s, q), xv in res["win"].items() if xv.X > 0.5]
    return sorted(out, key=lambda w: (w[1], w[2]))


def shifted_plan(plan, D):
    """Plan with the holds of the delay variant: a node's time is its departure time,
    original time plus the holds at this node and every node before it (as in the
    shift of the models, sead_models._holds)."""
    out = {}
    for r, p in plan.items():
        nodes = SI.route_nodes(p)
        times, cum = {}, 0.0
        for j, n in enumerate(nodes):
            if (r, j) in D:
                cum += D[(r, j)].X
            times[n] = p["times"][n] + cum
        out[r] = {"arcs": p["arcs"], "times": times}
    return out


def read_B(res, tag, plan):
    """Solution of a solved Paper B model, in plain data, plus the checker's verdict."""
    inst = res["inst"]
    V = {v["id"]: v for v in inst["suppressors"]}
    T = {t["id"]: t for t in inst["targets"]}
    wins = windows_ti(res) if tag == "ti" else SM.windows_from(res)
    used = sorted(set(w[1] for w in wins))
    sol = {"windows": [[w[0], w[1], _num(w[2]), _num(w[3])] for w in wins],
           "assets_used": used,
           "assets_by_kind": {},
           "supp_cost": sum(float(V[v]["cost"]) for v in used)}
    for v in used:
        k = V[v]["kind"]
        sol["assets_by_kind"][k] = sol["assets_by_kind"].get(k, 0) + 1
    sol["windows_by_kind"] = {}
    for w in wins:
        k = V[w[1]]["kind"]
        sol["windows_by_kind"][k] = sol["windows_by_kind"].get(k, 0) + 1
    val = {r: sum(T[a["head"]]["value"] for a in p["arcs"] if a["head"] in T) for r, p in plan.items()}
    sol["value_plan"] = sum(val.values())
    flown = list(plan)
    if res["kappa"]:
        flown = [r for r, k in res["kappa"].items() if k.X > 0.5]
        sol["flown"] = flown
        sol["value_flown"] = sum(val[r] for r in flown)
    p_check = plan
    if res["D"]:
        hold = {r: sum(v.X for (rr, j), v in res["D"].items() if rr == r) for r in plan}
        sol["hold"] = {r: _num(h) for r, h in hold.items()}
        sol["hold_total"] = _num(sum(hold.values()))
        sol["holds_at"] = {r: {str(j): _num(v.X) for (rr, j), v in sorted(res["D"].items())
                               if rr == r and abs(v.X) > 1e-9} for r in plan}   # per route node
        p_check = shifted_plan(plan, res["D"])
    p_check = {r: p_check[r] for r in flown}
    labelled = [(w[0], w[1], w[2], w[3]) for w in wins]
    # The checker runs on the solution read at whole minutes (sead_check.snap_solution, decided
    # 2026-11-25): binaries within the solver's integrality tolerance shorten windows by up to
    # 1e-4 min. The verdict on the solver's values as read is kept in check_raw.
    sol["check_raw"] = SC.check_solution(inst, p_check, labelled)
    p_s, w_s = SC.snap_solution(inst, p_check, labelled)
    viol = SC.check_solution(inst, p_s, w_s)
    full = []
    if tag == "slot":
        n_slots, per_site = {}, {}
        for k in res["sig"]:
            s = k.rsplit("_k", 1)[0]
            n_slots[s] = n_slots.get(s, 0) + 1
        for w in wins:
            s = w[0].rsplit("_k", 1)[0]
            per_site[s] = per_site.get(s, 0) + 1
        full = [s for s, c in per_site.items() if c >= n_slots[s]]
    return sol, viol, full


def run_one_B(path, tag, builder, var, kw, out_path, log_dir):
    inst = SI.load_instance(path)
    plan = SI.plan_from_instance(inst)
    rec = {"instance": inst["name"], "paper": "B", "model": tag, "variant": var,
           "delay": kw.get("delay"), "select": bool(kw.get("select")),
           "class": _instance_class(inst), "settings": SETTINGS, "gurobi": gurobi_version(),
           "model_options": MODEL_OPTIONS.get(tag, {})}
    t0 = time.time()
    res = builder(inst, plan, time_limit=SETTINGS["time_limit"], threads=SETTINGS["threads"],
                  mip_gap=SETTINGS["mip_gap"], **kw)
    m = res["model"]
    if hasattr(m, "update"):
        m.update()
    rec["build_time"] = time.time() - t0
    rec["n_stays"] = len(res["stays"])
    rec["stays"] = [[h["site"], h["start"], h["end"], h["striker"], h["leg"]] for h in res["stays"]]
    rec["vars"], rec["constrs"] = _attr(m, "NumVars"), _attr(m, "NumConstrs")
    rec["bin_vars"] = _attr(m, "NumBinVars")
    _use_log(m, os.path.join(log_dir, os.path.basename(out_path)[:-5] + ".log"))
    m.optimize()
    if m.Status == INTERRUPTED:
        raise KeyboardInterrupt
    rec["status"] = STATUS.get(m.Status, str(m.Status))
    rec["status_code"] = m.Status
    rec["runtime"] = _num(m.Runtime)
    rec["nodes"] = _num(_attr(m, "NodeCount"))
    rec["sol_count"] = m.SolCount
    rec["obj"] = _num(m.ObjVal) if m.SolCount > 0 else None
    rec["bound"] = _num(_attr(m, "ObjBound")) if m.Status in (GRB.OPTIMAL, GRB.TIME_LIMIT) else None
    rec["gap"] = _num(_attr(m, "MIPGap")) if m.SolCount > 0 else None
    if m.SolCount > 0:
        rec["solution"], rec["check"], rec["slots_full"] = read_B(res, tag, plan)
        rec["check_ok"] = not rec["check"]
    else:
        rec["solution"], rec["check"], rec["slots_full"], rec["check_ok"] = None, [], [], None
    rec["lp"] = _solve_lp(m)
    rec["saved_at"] = datetime.now().isoformat(timespec="seconds")
    if hasattr(m, "dispose"):
        m.dispose()
    return rec


# ------------------------------------------------------------------ Paper B loop
def jobs_B(only=None, models=None, variants=None):
    files = sorted(glob.glob(os.path.join(INST_B, "B_*.json")))
    if only:
        files = [f for f in files if any(s in os.path.basename(f) for s in only)]
    jobs = []
    for f in files:
        name = os.path.basename(f)[:-5]
        for var, kw in variants_B():
            if variants and var not in variants:
                continue
            for tag, builder in MODELS_B:
                if models and tag not in models:
                    continue
                out_path = os.path.join(OUT_B, "%s__%s__%s.json" % (name, tag, var))
                jobs.append((f, tag, builder, var, kw, out_path))
    return jobs


def _done(path):
    if not os.path.exists(path):
        return False
    try:
        return _load(path).get("status") not in ("error", str(INTERRUPTED))
    except Exception:
        return False


def run_paperB(only=None, models=None, variants=None, verbose=True):
    """Run every Paper B job not yet saved. only: list of name parts, e.g. ['B_R2'].
    Safe to stop (Kernel > Interrupt) and to call again."""
    log_dir = os.path.join(OUT_B, "logs")
    for d in (OUT_B, log_dir):
        if not os.path.isdir(d):
            os.makedirs(d)
    with open(os.path.join(OUT_B, "_run_info.jsonl"), "a") as f:
        f.write(json.dumps(run_info()) + "\n")
    jobs = jobs_B(only, models, variants)
    todo = [j for j in jobs if not _done(j[5])]
    print("Paper B: %d runs in total, %d already saved, %d to go. Gurobi %s, %s"
          % (len(jobs), len(jobs) - len(todo), len(todo), gurobi_version(), SETTINGS))
    t_start = time.time()
    for n, (f, tag, builder, var, kw, out_path) in enumerate(todo, 1):
        try:
            rec = run_one_B(f, tag, builder, var, kw, out_path, log_dir)
        except KeyboardInterrupt:
            print("\nStopped by the user after %d runs. Saved runs are kept: run the cells again to resume." % (n - 1))
            raise          # so that Jupyter does not go on to the next cell
        except Exception as e:
            rec = {"instance": os.path.basename(f)[:-5], "paper": "B", "model": tag, "variant": var,
                   "status": "error", "error": repr(e), "traceback": traceback.format_exc(),
                   "saved_at": datetime.now().isoformat(timespec="seconds")}
        _dump(rec, out_path)
        if verbose:
            obj = rec.get("obj")
            chk = {True: "check ok", False: "CHECK FAILED", None: "-"}[rec.get("check_ok")] \
                if rec.get("status") != "error" else rec.get("error", "")[:60]
            print("[%3d/%d] %-26s %-4s %-8s %-11s obj %-9s %7.1f s  %s%s"
                  % (n, len(todo), rec["instance"], tag, var, rec["status"],
                     "-" if obj is None else "%.2f" % obj, rec.get("runtime") or 0.0, chk,
                     "  SLOTS FULL " + ",".join(rec["slots_full"]) if rec.get("slots_full") else ""))
    print("Finished: %d runs in %.1f min. Next: R.summarize_paperB()" % (len(todo), (time.time() - t_start) / 60))


# Reruns at 3600 s (decided 2026-11-23, run 2026-11-25 at Serhat's request): the Paper B runs that neither
# formulation solved within 600 s. Only the time-indexed formulation, which had the better bound on all four.
# Saved apart in results/step5/paperB_3600/, so the 600 s records and tables stay as they are.
LONG_B = [("B_R6_S5_drone-rich-x3_2072", "delay15"), ("B_R6_S5_manned-rich-x3_2080", "delay15"),
          ("B_R6_S5_manned-rich-x3_2081", "delay15"), ("B_R6_S5_manned-rich_2081", "delay15")]
OUT_B_LONG = os.path.join(OUT, "paperB_3600")


def run_paperB_long(runs=None, tag="ti", time_limit=3600, verbose=True):
    """Rerun the runs in LONG_B with a longer time limit, other settings as in step 5. Safe to stop
    (Kernel > Interrupt) and to call again: saved runs are skipped."""
    global SETTINGS
    runs = LONG_B if runs is None else runs
    log_dir = os.path.join(OUT_B_LONG, "logs")
    for d in (OUT_B_LONG, log_dir):
        if not os.path.isdir(d):
            os.makedirs(d)
    builder, kws = dict(MODELS_B)[tag], dict(variants_B())
    todo = [(n, v) for n, v in runs
            if not _done(os.path.join(OUT_B_LONG, "%s__%s__%s.json" % (n, tag, v)))]
    old = SETTINGS
    SETTINGS = dict(old, time_limit=time_limit)
    print("Paper B reruns: %d runs, %d already saved, %d to go, at most %.1f h. Gurobi %s, %s"
          % (len(runs), len(runs) - len(todo), len(todo), len(todo) * time_limit / 3600.0, gurobi_version(), SETTINGS))
    t_start = time.time()
    try:
        for k, (name, var) in enumerate(todo, 1):
            out_path = os.path.join(OUT_B_LONG, "%s__%s__%s.json" % (name, tag, var))
            try:
                rec = run_one_B(os.path.join(INST_B, name + ".json"), tag, builder, var, kws[var], out_path, log_dir)
            except KeyboardInterrupt:
                print("\nStopped by the user after %d runs. Saved runs are kept: run the cell again to resume." % (k - 1))
                raise
            except Exception as e:
                rec = {"instance": name, "paper": "B", "model": tag, "variant": var, "status": "error",
                       "error": repr(e), "traceback": traceback.format_exc(),
                       "saved_at": datetime.now().isoformat(timespec="seconds")}
            _dump(rec, out_path)
            if verbose:
                print("[%d/%d] %-28s %-4s %-8s %-11s obj %-8s bound %-8s %7.1f s  %s"
                      % (k, len(todo), name, tag, var, rec["status"],
                         "-" if rec.get("obj") is None else "%.2f" % rec["obj"],
                         "-" if rec.get("bound") is None else "%.2f" % rec["bound"], rec.get("runtime") or 0.0,
                         {True: "check ok", False: "CHECK FAILED", None: "-"}.get(rec.get("check_ok"), "")))
    finally:
        SETTINGS = old
    print("Finished: %d runs in %.1f min." % (len(todo), (time.time() - t_start) / 60))


# ------------------------------------------------------------------ Paper B summary
CSV_FIELDS = ["instance", "strikers", "sites", "targets", "fleet_mix", "fleet_scale", "lead", "seed", "n_stays",
              "model", "variant",
              "delay", "status", "obj", "bound", "gap", "runtime", "nodes", "vars", "bin_vars", "constrs",
              "build_time", "lp_status", "lp_obj", "lp_runtime", "supp_cost", "n_assets", "n_windows",
              "manned_used", "jammer_used", "decoy_used", "value_plan", "value_flown", "n_flown",
              "hold_total", "check_ok", "slots_full"]


def _row(r):
    c, s, lp = r.get("class", {}), r.get("solution") or {}, r.get("lp") or {}
    k = s.get("assets_by_kind", {})
    return {"instance": r["instance"], "strikers": c.get("strikers"), "sites": c.get("sites"),
            "targets": c.get("targets"), "fleet_mix": c.get("fleet_mix"), "fleet_scale": c.get("fleet_scale"),
            "lead": c.get("lead"), "seed": c.get("seed"),
            "n_stays": r.get("n_stays"), "model": r["model"], "variant": r["variant"], "delay": r.get("delay"),
            "status": r["status"], "obj": r.get("obj"), "bound": r.get("bound"), "gap": r.get("gap"),
            "runtime": r.get("runtime"), "nodes": r.get("nodes"), "vars": r.get("vars"),
            "bin_vars": r.get("bin_vars"), "constrs": r.get("constrs"), "build_time": r.get("build_time"),
            "lp_status": lp.get("status"), "lp_obj": lp.get("obj"), "lp_runtime": lp.get("runtime"),
            "supp_cost": s.get("supp_cost"), "n_assets": len(s.get("assets_used", [])) if s else None,
            "n_windows": len(s.get("windows", [])) if s else None,
            "manned_used": k.get("manned SEAD aircraft", 0) if s else None,
            "jammer_used": k.get("jammer drone", 0) if s else None,
            "decoy_used": k.get("decoy drone", 0) if s else None,
            "value_plan": s.get("value_plan"), "value_flown": s.get("value_flown"),
            "n_flown": len(s["flown"]) if "flown" in s else None, "hold_total": s.get("hold_total"),
            "check_ok": r.get("check_ok"), "slots_full": ";".join(r.get("slots_full") or [])}


def _snap_note(runs):
    """Runs whose solution passes the checker at whole minutes but not on the solver's values as
    read (solver tolerance, sead_check.snap_solution). Information, not a problem."""
    n = [r for r in runs if r.get("check_ok") and (r.get("solution") or {}).get("check_raw")]
    print("\nPass only when read at whole minutes (solver tolerance): %d" % len(n))
    for r in n:
        print("  %s %s %s: %s" % (r["instance"], r.get("model", r.get("run")), r.get("variant", ""),
                                  "; ".join(r["solution"]["check_raw"][:2])))


def load_B():
    return [_load(p) for p in sorted(glob.glob(os.path.join(OUT_B, "B_*.json")))]


def summarize_paperB(write_csv=True):
    """Consistency checks over all saved Paper B runs. Returns a list of problems."""
    runs = load_B()
    if not runs:
        print("No saved Paper B runs yet.")
        return []
    if write_csv:
        with open(os.path.join(OUT, "paperB_runs.csv"), "w", newline="") as f:
            wr = csv.DictWriter(f, fieldnames=CSV_FIELDS)
            wr.writeheader()
            for r in runs:
                wr.writerow(_row(r))
    problems = []
    counts = {}
    for r in runs:
        key = (r["model"], r["variant"], r["status"])
        counts[key] = counts.get(key, 0) + 1
    print("Saved runs: %d of %d" % (len(runs), len(jobs_B())))
    print("\nStatus by model and variant:")
    for key in sorted(counts):
        print("  %-4s %-8s %-24s %d" % (key[0], key[1], key[2], counts[key]))
    by = {(r["instance"], r["model"], r["variant"]): r for r in runs}
    for r in runs:
        if r["status"] == "error":
            problems.append("error: %s %s %s: %s" % (r["instance"], r["model"], r["variant"], r.get("error")))
        if r.get("check_ok") is False:
            problems.append("checker: %s %s %s: %s" % (r["instance"], r["model"], r["variant"], r["check"][:3]))
        if r.get("slots_full") and not (r.get("model_options") or {}).get("trim"):
            # with one slot per stay (trim) a full site is exact, not a restriction
            problems.append("slots full: %s %s at %s" % (r["instance"], r["variant"], r["slots_full"]))
        if r["status"] == "time limit":
            problems.append("time limit: %s %s %s (gap %s)" % (r["instance"], r["model"], r["variant"], r.get("gap")))
    insts = sorted(set(r["instance"] for r in runs))
    names = [v for v, _ in variants_B()]
    for i in insts:
        for v in names:                                            # slot against time-indexed
            a, b = by.get((i, "slot", v)), by.get((i, "ti", v))
            if not a or not b:
                continue
            fa, fb = a["status"] == "optimal", b["status"] == "optimal"
            inf = ("infeasible", "infeasible or unbounded")
            if fa and fb and abs(a["obj"] - b["obj"]) > TOL:
                problems.append("slot and ti differ: %s %s: %.4f against %.4f" % (i, v, a["obj"], b["obj"]))
            if (fa and b["status"] in inf) or (fb and a["status"] in inf):
                problems.append("slot and ti differ in feasibility: %s %s: %s against %s"
                                % (i, v, a["status"], b["status"]))
        for tag in ("slot", "ti"):                                 # a larger delay bound never hurts
            seq = [by.get((i, tag, v)) for v in ["fixed"] + ["delay%d" % d for d in DELAYS]]
            prev = None
            for v, r in zip(["fixed"] + ["delay%d" % d for d in DELAYS], seq):
                if r is None or r["status"] not in ("optimal",) + ("infeasible", "infeasible or unbounded"):
                    prev = None
                    continue
                cur = r["obj"] if r["status"] == "optimal" else float("inf")
                if prev is not None and cur > prev[1] + TOL:
                    problems.append("delay not monotone: %s %s: %s %.4f, %s %s"
                                    % (i, tag, prev[0], prev[1], v, cur))
                prev = (v, cur)
    print("\nProblems found: %d" % len(problems))
    for p in problems:
        print("  " + p)
    _snap_note(runs)
    if write_csv:
        print("\nWrote results/step5/paperB_runs.csv")
    return problems


# ================================================================== Paper A exact set
# Decided with Serhat (2026-11-23 and 2026-11-24): 60 instances with 4 to 10 targets, 600 s,
# 8 threads, gap 0, strikers free to wait for drones (lead in the instances). Runs per instance:
#   full         integrated model, tight constants, symmetry, window-length inequalities
#   A            Version A, zones removed before the model is written (RQ2)
#   free         zones ignored (upper bound, and the planner of the sequential baseline)
#   seq_fixed    sequential baseline: routes of 'free', all strikers launch at H-hour (the lead),
#                then Paper B sortie selection with times fixed (time-indexed model)
#   seq_delay15  the same with holds of at most 15 min per striker
#   no_drones    integrated, full settings, manned suppressors only (RQ3)
#   full_slots2  check: 'full' with two more slots per site. Windows cost nothing (the cost is per
#                asset), so an optimum often uses every slot without needing them. If this run beats
#                'full', the slot number was binding on that instance and its runs need more slots.
#   tight_sym, tight, loose   the integrated model with fewer strengthenings (RQ1)
INST_A = os.path.join(ROOT, "instances", "paperA")
OUT_A = os.path.join(OUT, "paperA")
FULL = {"tight": True, "sym": True, "vi": True}
RUNS_A = [("full", "integrated", FULL), ("A", "A", {}), ("free", "free", {}),
          ("seq_fixed", None, {"select": True}), ("seq_delay15", None, {"select": True, "delay": 15}),
          ("no_drones", "no_drones", FULL),
          ("full_slots2", "integrated", dict(FULL, slots_extra=2)),
          ("tight_sym", "integrated", {"tight": True, "sym": True, "vi": False}),
          ("tight", "integrated", {"tight": True, "sym": False, "vi": False}),
          ("loose", "integrated", {"tight": False, "sym": False, "vi": False})]
MAIN_A = ["full", "A", "free", "seq_fixed", "seq_delay15", "no_drones"]
CHECK_A = ["full_slots2"]
RQ1_A = ["tight_sym", "tight", "loose"]


def _routes(plan):
    return {r: [a["id"] for a in p["arcs"]] for r, p in plan.items()}


def _read_A(res, run, inst):
    """Solution of a solved Paper A model, in plain data, plus the checker's verdict."""
    V = {v["id"]: v for v in inst["suppressors"]}
    T = {t["id"]: t for t in inst["targets"]}
    plan = SM.plan_from_A(res)
    wins = SM.windows_from(res) if "sig" in res else []
    used = sorted(set(w[1] for w in wins))
    attacked = [i for i in T if res["y"][i].X > 0.5]
    stays = SI.stays_from_plan(inst, plan)
    sol = {"value": sum(T[i]["value"] for i in attacked), "attacked": attacked,
           "value_all": sum(t["value"] for t in inst["targets"]),
           "Tmax": _num(res["Tmax"].X), "routes": _routes(plan),
           "times": {r: {n: _num(x) for n, x in p["times"].items()} for r, p in plan.items()},
           "launch": {r: _num(p["times"]["o_" + r]) for r, p in plan.items()},
           "n_stays": len(stays), "windows": [[w[0], w[1], _num(w[2]), _num(w[3])] for w in wins],
           "assets_used": used, "supp_cost": sum(float(V[v]["cost"]) for v in used), "assets_by_kind": {}}
    for v in used:
        k = V[v]["kind"]
        sol["assets_by_kind"][k] = sol["assets_by_kind"].get(k, 0) + 1
    wl = [tuple(w) for w in wins]
    raw = SC.check_solution(inst, plan, wl)            # solver values as read
    p_s, w_s = SC.snap_solution(inst, plan, wl)        # whole minutes (2026-11-25), as in read_B
    viol = SC.check_solution(inst, p_s, w_s)
    if run == "free":                      # zones ignored by design: check everything but coverage
        raw = [x for x in raw if not x.startswith("stay of")]
        viol = [x for x in viol if not x.startswith("stay of")]
    sol["check_raw"] = raw
    per_site = {}
    for w in wins:
        s = w[0].split("_")[0]
        per_site[s] = per_site.get(s, 0) + 1
    full = [s for s, c in per_site.items() if c >= int(inst["slots_per_site"])]
    return sol, viol, full


def _base_rec(inst, run, version, kw):
    return {"instance": inst["name"], "paper": "A", "run": run, "version": version, "settings_model": kw,
            "class": _instance_class(inst), "settings": SETTINGS, "gurobi": gurobi_version()}


def _solve_and_record(rec, res, log_path):
    m = res["model"]
    if hasattr(m, "update"):
        m.update()
    rec["vars"], rec["constrs"], rec["bin_vars"] = _attr(m, "NumVars"), _attr(m, "NumConstrs"), _attr(m, "NumBinVars")
    _use_log(m, log_path)
    m.optimize()
    if m.Status == INTERRUPTED:
        raise KeyboardInterrupt
    rec["status"] = STATUS.get(m.Status, str(m.Status))
    rec["status_code"] = m.Status
    rec["runtime"] = _num(m.Runtime)
    rec["nodes"] = _num(_attr(m, "NodeCount"))
    rec["sol_count"] = m.SolCount
    rec["obj"] = _num(m.ObjVal) if m.SolCount > 0 else None
    rec["bound"] = _num(_attr(m, "ObjBound")) if m.Status in (GRB.OPTIMAL, GRB.TIME_LIMIT) else None
    rec["gap"] = _num(_attr(m, "MIPGap")) if m.SolCount > 0 else None
    return m


def run_one_A(path, run, version, kw, out_path, log_dir):
    inst = SI.load_instance(path)
    rec = _base_rec(inst, run, version, kw)
    kw = dict(kw)
    extra = kw.pop("slots_extra", 0)
    if extra:
        inst = dict(inst, slots_per_site=int(inst["slots_per_site"]) + extra)
        rec["slots_per_site"] = inst["slots_per_site"]
    log_path = os.path.join(log_dir, os.path.basename(out_path)[:-5] + ".log")
    t0 = time.time()
    if version is not None:                                     # a Paper A model
        res = SM.build_paper_A(inst, version, time_limit=SETTINGS["time_limit"], threads=SETTINGS["threads"],
                               mip_gap=SETTINGS["mip_gap"], **kw)
        rec["build_time"] = time.time() - t0
        m = _solve_and_record(rec, res, log_path)
        if m.SolCount > 0:
            rec["solution"], rec["check"], rec["slots_full"] = _read_A(res, run, inst)
            rec["check_ok"] = not rec["check"]
        else:
            rec["solution"], rec["check"], rec["slots_full"], rec["check_ok"] = None, [], [], None
    else:                                                       # sequential baseline
        fpath = out_path.replace("__" + run + ".json", "__free.json")
        fr = _load(fpath)
        if not fr.get("solution"):
            raise RuntimeError("zones-free run has no solution, so no sequential plan")
        L = float(inst.get("lead", 0))
        plan = SI.plan_from_routes(inst, fr["solution"]["routes"], {r: L for r in fr["solution"]["routes"]})
        rec["paperB_model"] = "ti"
        rec["free_status"] = fr["status"]
        res = SM.build_paper_B_ti(inst, plan, time_limit=SETTINGS["time_limit"], threads=SETTINGS["threads"],
                                  mip_gap=SETTINGS["mip_gap"], **kw)
        rec["build_time"] = time.time() - t0
        rec["n_stays"] = len(res["stays"])
        m = _solve_and_record(rec, res, log_path)
        if m.SolCount > 0:
            sol, viol, _ = read_B(res, "ti", plan)
            flown = sol.get("flown", list(plan))
            pl = shifted_plan(plan, res["D"]) if res["D"] else plan
            ends = [pl[r]["times"]["d_" + r] for r in flown if len(plan[r]["arcs"]) > 1 or plan[r]["arcs"][0]["time"] > 0]
            sol["Tmax"] = _num(max(ends)) if ends else 0.0
            sol["value"] = sol.get("value_flown", 0)
            sol["routes"] = fr["solution"]["routes"]
            sol["obj_A_terms"] = _num(sol["value"] - sol["supp_cost"] - inst["mu"] * sol["Tmax"])
            rec["solution"], rec["check"], rec["slots_full"] = sol, viol, []
            rec["check_ok"] = not viol
        else:
            rec["solution"], rec["check"], rec["slots_full"], rec["check_ok"] = None, [], [], None
    rec["lp"] = _solve_lp(m)
    rec["saved_at"] = datetime.now().isoformat(timespec="seconds")
    if hasattr(m, "dispose"):
        m.dispose()
    return rec


def _n_targets(path):
    return int(os.path.basename(path).split("_")[1][1:])


def jobs_A(only=None, runs=None):
    files = [f for f in glob.glob(os.path.join(INST_A, "A_*.json")) if _n_targets(f) <= 10]
    files.sort(key=lambda f: (_n_targets(f), os.path.basename(f)))
    if only:
        files = [f for f in files if any(s in os.path.basename(f) for s in only)]
    jobs = []
    for f in files:
        name = os.path.basename(f)[:-5]
        for run, version, kw in RUNS_A:
            if runs and run not in runs:
                continue
            jobs.append((f, run, version, kw, os.path.join(OUT_A, "%s__%s.json" % (name, run))))
    return jobs


def run_paperA(runs=None, only=None, verbose=True):
    """Run every Paper A job not yet saved. runs: list of run names (default all), e.g. R.MAIN_A.
    only: list of name parts, e.g. ['A_T4']. Safe to stop (Kernel > Interrupt) and to call again."""
    log_dir = os.path.join(OUT_A, "logs")
    for d in (OUT_A, log_dir):
        if not os.path.isdir(d):
            os.makedirs(d)
    with open(os.path.join(OUT_A, "_run_info.jsonl"), "a") as f:
        f.write(json.dumps(run_info()) + "\n")
    jobs = jobs_A(only, runs)
    todo = [j for j in jobs if not _done(j[4])]
    print("Paper A: %d runs in total, %d already saved, %d to go. Gurobi %s, %s"
          % (len(jobs), len(jobs) - len(todo), len(todo), gurobi_version(), SETTINGS))
    t_start = time.time()
    for n, (f, run, version, kw, out_path) in enumerate(todo, 1):
        try:
            rec = run_one_A(f, run, version, kw, out_path, log_dir)
        except KeyboardInterrupt:
            print("\nStopped by the user after %d runs. Saved runs are kept: run the cells again to resume." % (n - 1))
            raise
        except Exception as e:
            rec = {"instance": os.path.basename(f)[:-5], "paper": "A", "run": run, "status": "error",
                   "error": repr(e), "traceback": traceback.format_exc(),
                   "saved_at": datetime.now().isoformat(timespec="seconds")}
        _dump(rec, out_path)
        if verbose:
            s = rec.get("solution") or {}
            obj = s.get("obj_A_terms", rec.get("obj"))         # sequential runs: integrated objective terms
            chk = {True: "check ok", False: "CHECK FAILED", None: "-"}[rec.get("check_ok")] \
                if rec.get("status") != "error" else rec.get("error", "")[:60]
            print("[%3d/%d] %-28s %-11s %-11s obj %-8s value %-4s %7.1f s  %s%s"
                  % (n, len(todo), rec["instance"], run, rec["status"], "-" if obj is None else "%.2f" % obj,
                     s.get("value", "-"), rec.get("runtime") or 0.0, chk,
                     "  (all slots used at " + ",".join(rec["slots_full"]) + ")" if rec.get("slots_full") else ""))
    print("Finished: %d runs in %.1f min." % (len(todo), (time.time() - t_start) / 60))


CSV_FIELDS_A = ["instance", "targets", "strikers", "sites", "fleet_mix", "lead", "seed", "run", "status", "obj",
                "obj_A_terms", "bound", "gap", "runtime", "nodes", "vars", "bin_vars", "constrs", "build_time",
                "lp_status", "lp_obj", "value", "value_all", "supp_cost", "Tmax", "n_stays", "n_windows",
                "manned_used", "jammer_used", "decoy_used", "n_flown", "hold_total", "check_ok", "slots_full"]


def _row_A(r):
    c, s, lp = r.get("class", {}), r.get("solution") or {}, r.get("lp") or {}
    k = s.get("assets_by_kind", {})
    obj_terms = s.get("obj_A_terms", r.get("obj") if r.get("run") not in ("seq_fixed", "seq_delay15") else None)
    return {"instance": r["instance"], "targets": c.get("targets"), "strikers": c.get("strikers"),
            "sites": c.get("sites"), "fleet_mix": c.get("fleet_mix"), "lead": c.get("lead"), "seed": c.get("seed"),
            "run": r["run"], "status": r["status"], "obj": r.get("obj"), "obj_A_terms": obj_terms,
            "bound": r.get("bound"), "gap": r.get("gap"), "runtime": r.get("runtime"), "nodes": r.get("nodes"),
            "vars": r.get("vars"), "bin_vars": r.get("bin_vars"), "constrs": r.get("constrs"),
            "build_time": r.get("build_time"), "lp_status": lp.get("status"), "lp_obj": lp.get("obj"),
            "value": s.get("value"), "value_all": s.get("value_all"), "supp_cost": s.get("supp_cost"),
            "Tmax": s.get("Tmax"), "n_stays": s.get("n_stays", r.get("n_stays")),
            "n_windows": len(s.get("windows", [])) if s else None,
            "manned_used": k.get("manned SEAD aircraft", 0) if s else None,
            "jammer_used": k.get("jammer drone", 0) if s else None,
            "decoy_used": k.get("decoy drone", 0) if s else None,
            "n_flown": len(s["flown"]) if "flown" in s else None, "hold_total": s.get("hold_total"),
            "check_ok": r.get("check_ok"), "slots_full": ";".join(r.get("slots_full") or [])}


def load_A():
    return [_load(p) for p in sorted(glob.glob(os.path.join(OUT_A, "A_*.json")))]


def summarize_paperA(write_csv=True):
    """Consistency checks over all saved Paper A runs. Returns a list of problems.
    Expected relations between optima (integrated objective terms: value - suppression cost - mu T max):
    loose = tight = tight_sym = full; A <= full (zones removed is a restriction); free >= full
    (zones ignored is a relaxation); no_drones <= full; seq_fixed <= seq_delay15 <= full (a sequential
    plan above the integrated optimum means the slots of the integrated model were too few);
    full_slots2 = full (above: slots binding; below: impossible)."""
    runs = load_A()
    if not runs:
        print("No saved Paper A runs yet.")
        return []
    if write_csv:
        with open(os.path.join(OUT, "paperA_runs.csv"), "w", newline="") as f:
            wr = csv.DictWriter(f, fieldnames=CSV_FIELDS_A)
            wr.writeheader()
            for r in runs:
                wr.writerow(_row_A(r))
    problems, counts, filled = [], {}, 0
    for r in runs:
        counts[(r["run"], r["status"])] = counts.get((r["run"], r["status"]), 0) + 1
    print("Saved runs: %d of %d" % (len(runs), len(jobs_A())))
    print("\nStatus by run:")
    for key in sorted(counts):
        print("  %-12s %-24s %d" % (key[0], key[1], counts[key]))
    by = {(r["instance"], r["run"]): r for r in runs}
    for r in runs:
        tag = "%s %s" % (r["instance"], r["run"])
        if r["status"] == "error":
            problems.append("error: %s: %s" % (tag, r.get("error")))
        if r.get("check_ok") is False:
            problems.append("checker: %s: %s" % (tag, r["check"][:3]))
        if r.get("slots_full"):
            filled += 1
        if r["status"] == "time limit":
            problems.append("time limit: %s (gap %s)" % (tag, r.get("gap")))
    print("\nRuns that used every slot at some site (information only, see full_slots2): %d" % filled)

    def val(i, run):
        r = by.get((i, run))
        if not r or r["status"] != "optimal" or not r.get("solution"):
            return None
        return r["solution"].get("obj_A_terms", r["obj"])

    for i in sorted(set(r["instance"] for r in runs)):
        f = val(i, "full")
        for run in ("tight_sym", "tight", "loose"):
            v = val(i, run)
            if v is not None and f is not None and abs(v - f) > TOL:
                problems.append("RQ1 optima differ: %s %s %.4f against full %.4f" % (i, run, v, f))
        rel = [("A", "<="), ("no_drones", "<="), ("seq_fixed", "<="), ("seq_delay15", "<="), ("free", ">=")]
        for run, op in rel:
            v = val(i, run)
            if v is None or f is None:
                continue
            if (op == "<=" and v > f + TOL) or (op == ">=" and v < f - TOL):
                problems.append("expected %s %s full: %s %.4f against %.4f" % (run, op, i, v, f))
        v = val(i, "full_slots2")
        if v is not None and f is not None and v > f + TOL:
            problems.append("slots binding: %s full_slots2 %.4f against full %.4f (rerun with more slots)" % (i, v, f))
        if v is not None and f is not None and v < f - TOL:
            problems.append("more slots gave a worse optimum: %s %.4f against %.4f" % (i, v, f))
        a, b = val(i, "seq_fixed"), val(i, "seq_delay15")
        if a is not None and b is not None and a > b + TOL:
            problems.append("holds made the sequential plan worse: %s %.4f against %.4f" % (i, a, b))
    print("\nProblems found: %d" % len(problems))
    for p in problems:
        print("  " + p)
    _snap_note(runs)
    if write_csv:
        print("\nWrote results/step5/paperA_runs.csv")
    return problems
