"""Mirror instance files in x before they are shared (decided by Serhat on 2026-11-24).

    python mirror_instances.py SOURCE_FOLDER TARGET_FOLDER        (from the code folder)

The generator (sead_generator.py) puts the base at the middle of the western edge. The papers draw
every map mirrored, with the base in the east, so the shared instance files are mirrored too:
every x coordinate becomes width - x (base and target positions, SAM site centres, suppression
stations, and the points of the detour paths). A mirror image keeps every distance, so no flight
time, zone stay, plan or result changes. Each mirrored file gets the field "mirrored", which
paperB_tables.fig_map reads so that it does not mirror the map a second time. The source files are
not changed.
"""
import glob
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def width_of_theatre():
    try:
        import sead_generator
        return float(sead_generator.THEATRE["width"])
    except Exception:                                   # the generator needs no solver, but stay safe
        return 300.0


def mirror(inst, width):
    if inst.get("mirrored"):
        raise ValueError("%s is already mirrored" % inst.get("name"))
    X = lambda p: [round(width - p[0], 6), p[1]]
    inst = json.loads(json.dumps(inst))
    inst["positions"] = {k: X(v) for k, v in inst["positions"].items()}
    for s in inst["sites"]:
        s["center"] = X(s["center"])
    inst["stations"] = {k: X(v) for k, v in inst["stations"].items()}
    for leg in inst["legs"]:
        for var in leg["variants"]:
            if "path" in var:
                var["path"] = [X(p) for p in var["path"]]
    inst["mirrored"] = {"axis": "x", "width": width,
                        "note": "x replaced by width - x after generation, so that the base lies in the east; "
                                "distances, times and results are unchanged"}
    return inst


def main(src, dst):
    width = width_of_theatre()
    os.makedirs(dst, exist_ok=True)
    files = sorted(glob.glob(os.path.join(src, "*.json")))
    for f in files:
        with open(f) as fi:
            inst = json.load(fi)
        out = mirror(inst, width)
        with open(os.path.join(dst, os.path.basename(f)), "w") as fo:
            json.dump(out, fo, indent=1)
    print("Mirrored %d instance files (width %.0f km) into %s" % (len(files), width, dst))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2])
