"""Worked example of Paper B (step 6), separate from the worked scenario of Paper A.

Two strikers, two SAM sites, three suppression assets (one manned SEAD aircraft, one jammer
drone, one decoy drone). The plan has three zone stays:
    h1  striker S1 in zone s1 from minute 40 to 54 (14 min)
    h2  striker S2 in zone s2 from minute 56 to 70 (14 min)
    h3  striker S1 in zone s2 from minute 80 to 84 (4 min)
Only the manned aircraft has a window of at least 14 minutes, and it cannot close a window at s1
at minute 54 and open one at s2 by minute 56 (4 minutes between the stations). Expected:
    times fixed       infeasible
    sortie selection  S1 flown (value 14), S2 cancelled (value 12), objective 14 - 3 = 11
    holds up to 5 min S2 holds 2 minutes at the base, the manned aircraft covers all three stays,
                      objective 3 + 0.01 x 2 = 3.02
Solved with both formulations, every solution checked by sead_check. Run from the code folder:
    python paperB_example.py            (Gurobi, saves results/paperB_example.json)
Python 3.9.
"""
import json
import os
import sys

import sead_check as SC
import sead_instance as SI
import sead_models as SM

HERE = os.path.dirname(os.path.abspath(__file__))


def example():
    leg = lambda a, b, variants: {"from": a, "to": b, "variants": variants}
    var = lambda t, site=None, entry=0, exit_=0: {"time": t, "site": site, "entry": entry, "exit": exit_}
    asset = lambda vid, kind, manned, window, endurance, cost, expendable, t0, tss: {
        "id": vid, "kind": kind, "manned": manned, "window": window, "endurance": endurance, "cost": cost,
        "expendable": expendable, "sites": ["s1", "s2"], "base_to_site": t0, "site_to_base": dict(t0),
        "site_to_site": [["s1", "s2", tss]]}
    return {
        "name": "paperB_example", "H_bar": 150, "mu": 0.01, "slots_per_site": 3, "base": "B", "lead": 30,
        "strikers": [{"id": "S1", "weapons": 2, "endurance": 120}, {"id": "S2", "weapons": 2, "endurance": 120}],
        "targets": [{"id": "T1", "value": 8, "weapons": 1, "tw": [0, 150]},
                    {"id": "T2", "value": 12, "weapons": 1, "tw": [0, 150]},
                    {"id": "T3", "value": 6, "weapons": 1, "tw": [0, 150]}],
        "sites": [{"id": "s1", "inside": []}, {"id": "s2", "inside": []}],
        # entry and exit in minutes after leaving 'from'; the reverse direction is mirrored
        "legs": [leg("B", "T1", [var(30, "s1", 10, 24)]),
                 leg("T1", "T3", [var(15)]),
                 leg("B", "T3", [var(35, "s2", 26, 30)]),
                 leg("B", "T2", [var(34, "s2", 14, 28), var(50)])],
        "suppressors": [asset("M1", "manned SEAD aircraft", True, 20, 150, 3.0, False, {"s1": 15, "s2": 20}, 4),
                        asset("J1", "jammer drone", False, 12, 300, 1.0, False, {"s1": 40, "s2": 45}, 16),
                        asset("D1", "decoy drone", False, 5, 120, 0.5, True, {"s1": 30, "s2": 34}, 12)],
        "supp_travel": {"base_to_site": {}, "site_to_base": {}, "site_to_site": []},
        # S1: out through s1, on to T3, home through s2. S2: out through s2, home on the detour.
        "plan": {"S1": {"arcs": ["S1:o_S1>T1#0", "T1>T3#0", "S1:T3>d_S1#0"], "launch": 30},
                 "S2": {"arcs": ["S2:o_S2>T2#0", "S2:T2>d_S2#1"], "launch": 42}},
    }


def solve_all(time_limit=60):
    from step5_runner import read_B, windows_ti, STATUS, build_slot_B
    inst = example()
    plan = SI.plan_from_instance(inst)
    out = {"instance": inst, "stays": [[h["site"], h["start"], h["end"], h["striker"]]
                                       for h in SI.stays_from_plan(inst, plan)], "runs": {}}
    for tag, builder in (("slot", build_slot_B), ("ti", SM.build_paper_B_ti)):     # slot as in step 5
        for var, kw in (("fixed", {}), ("select", {"select": True}), ("delay5", {"delay": 5})):
            res = builder(inst, plan, time_limit=time_limit, **kw)
            m = res["model"]
            m.optimize()
            rec = {"status": STATUS.get(m.Status, str(m.Status))}
            if m.SolCount > 0:
                rec["obj"] = m.ObjVal
                rec["solution"], rec["check"], _ = read_B(res, tag, plan)
            out["runs"]["%s_%s" % (tag, var)] = rec
    return out


def check(out):
    bad = []
    for tag in ("slot", "ti"):
        f, s, d = (out["runs"]["%s_%s" % (tag, v)] for v in ("fixed", "select", "delay5"))
        if f["status"] not in ("infeasible", "infeasible or unbounded"):
            bad.append("%s fixed should be infeasible, got %s" % (tag, f["status"]))
        if abs(s.get("obj", -1) - 11) > 1e-6 or s["solution"].get("flown") != ["S1"]:
            bad.append("%s select: expected 11 with S1 flown, got %s %s" % (tag, s.get("obj"), s.get("solution", {}).get("flown")))
        if abs(d.get("obj", -1) - 3.02) > 1e-6 or abs(d["solution"]["hold"].get("S2", -1) - 2) > 1e-6:
            bad.append("%s delay5: expected 3.02 with a 2 min hold of S2, got %s %s" % (tag, d.get("obj"), d.get("solution", {}).get("hold")))
        for v in ("select", "delay5"):
            r = out["runs"]["%s_%s" % (tag, v)]
            if r.get("check"):
                bad.append("%s %s: checker %s" % (tag, v, r["check"]))
    return bad


if __name__ == "__main__":
    out = solve_all()
    print("stays:", out["stays"])
    for k, r in out["runs"].items():
        s = r.get("solution") or {}
        print("%-12s %-11s obj %-6s flown %s hold %s windows %s" % (k, r["status"], r.get("obj") and round(r["obj"], 4),
              s.get("flown"), s.get("hold"), s.get("windows")))
    bad = check(out)
    print("CHECK: " + ("all as expected" if not bad else "MISMATCHES:\n  " + "\n  ".join(bad)))
    if "--no-save" not in sys.argv:
        with open(os.path.join(HERE, "..", "results", "paperB_example.json"), "w") as f:
            json.dump(out, f, indent=1)
        print("saved results/paperB_example.json")
