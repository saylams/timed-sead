"""Tables and figures of Paper B, built from the saved Gurobi runs (step 6, INSTRUCTIONS.md rule 9).

Reads every run file in results/step5/paperB/ and the instances in instances/paperB/, and writes
to results/paperB/:
    table1_instances.csv      instance classes: plans, sites, zone stays, lead, fleet
    table2_formulations.csv   slot against time-indexed model: solved, time, nodes, LP gap, size
    table3_coverage.csv       plans coverable with times fixed and with holds of 5, 10, 15 min, cost
    table4_selection.csv      sortie selection: share of plan value kept
    table5_assets.csv         assets used by type and share of available assets used (decoys
                              included, for the decision on chaining of windows)
    table6_holds.csv          effect of holds on the same plans: cost against times fixed, newly coverable
    summary.md                the comparisons above in words and numbers, for drafting
    tables.md                 the paper versions of Tables 3 to 7 (selected columns), to paste into the draft.
                              Paper numbering (from 2026-11-26, Table 1 is the notation): Table 3 = table2, 4 = table3, 5 = table6, 6 = table4, 7 = table5
    figures/fig_profile.(png|pdf)   share of runs solved within a time, per model
    figures/fig_coverage.(png|pdf)  share of plans coverable against the hold bound
    figures/fig_example.(png|pdf)   worked example of Section 2.6: schematic map and the three cases over time,
                                    from results/paperB_example.json
    figures/fig_map.(png|pdf)       an example instance, drawn with the base in the east

Nothing here is typed by hand: every number comes from the run files. Definitions:
    solved       optimal, or proven infeasible, within the time limit
    time         shifted geometric mean of solution time, shift 1 s, time-limit runs at the limit
    LP gap       |MIP optimum - LP bound| / |MIP optimum|, optimal runs with a nonzero optimum
    agreement    slot against time-indexed on the same run: optimal values within 1e-6, and no run proven
                 infeasible by one model and solved to optimality by the other
    hold effect  on the plans with a proven optimal cost both with times fixed and with the hold bound:
                 cost reduction 100 (cost fixed - cost with holds) / cost fixed, hold penalty included
    reruns       the runs that neither formulation solved within 600 s, rerun with the time-indexed formulation
                 and 3600 s (results/step5/paperB_3600/). They settle coverage and proven optimal costs
                 (Tables 3 and 4, coverage figure) but do not enter the comparison of the formulations
                 (Table 2, profile figure), which stays at 600 s
    coverable    a plan is coverable in a variant if some model found it feasible. A larger hold bound
                 never hurts, so coverable at a bound implies coverable at every larger bound, and
                 proven not coverable at a bound implies not coverable at every smaller bound (used
                 only where no model settled the case within the time limit)
The map is mirrored (x drawn as width - x, decided by Serhat on 2026-11-24): a mirror image keeps
every distance, so no time or result changes.

Run from the code folder:  python paperB_tables.py [results folder] [instances folder] [output folder]
Python 3.9, standard library and matplotlib.
"""
import csv
import glob
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
RES = os.path.join(ROOT, "results", "step5", "paperB")
RES_LONG = os.path.join(ROOT, "results", "step5", "paperB_3600")   # reruns at 3600 s (2026-11-25)
INST = os.path.join(ROOT, "instances", "paperB")
OUT = os.path.join(ROOT, "results", "paperB")
EXAMPLE = os.path.join(ROOT, "results", "paperB_example.json")   # worked example, confirmed with Gurobi 2026-11-25

INFEAS = ("infeasible", "infeasible or unbounded")
VARIANTS = ["fixed", "delay5", "delay10", "delay15"]
BOUND = {"fixed": 0, "delay5": 5, "delay10": 10, "delay15": 15}
MODELS = ["slot", "ti"]
MODEL_NAME = {"slot": "continuous-time model", "ti": "time-indexed model"}
FIG_NAME = {"slot": "continuous-time formulation", "ti": "time-indexed formulation"}  # figure labels, as in the paper (2026-11-27)
KINDS = [("manned SEAD aircraft", "manned"), ("jammer drone", "jammer"), ("decoy drone", "decoy")]
# validated default palette, slots 1 and 2 (dataviz skill); markers and line styles added for print
COL = {"ti": "#2a78d6", "slot": "#eb6834", "base": "#2a78d6", "scaled": "#eb6834"}
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"


# ------------------------------------------------------------------ loading
def load_runs(folder):
    runs = []
    for p in sorted(glob.glob(os.path.join(folder, "B_*.json"))):
        with open(p) as f:
            r = json.load(f)
        if r.get("status") == "error":
            continue
        c = r.get("class", {})
        r["_R"] = c.get("strikers")
        r["_scale"] = c.get("fleet_scale", 1) or 1
        r["_level"] = "base" if r["_scale"] == 1 else "scaled"
        r["_mix"] = c.get("fleet_mix")
        runs.append(r)
    return runs


def cls_key(r):
    return (r["_R"], r["_level"])


def cls_name(k):
    return "%d strikers, %s fleet" % (k[0], k[1])


def solved(r):
    return r["status"] == "optimal" or r["status"] in INFEAS


def sgm(times, shift=1.0):
    if not times:
        return None
    return math.exp(sum(math.log(t + shift) for t in times) / len(times)) - shift


def mean(xs):
    xs = [x for x in xs if x is not None]
    return sum(xs) / len(xs) if xs else None


def fmt(x, nd=1):
    return "" if x is None else ("%.*f" % (nd, x))


def write_csv(path, header, rows):
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        for row in rows:
            w.writerow(row)


# ------------------------------------------------------------------ tables
def table1(runs, inst_dir):
    by = {}
    for r in runs:
        if r["model"] == "ti" and r["variant"] == "fixed":
            by.setdefault(cls_key(r), []).append(r)
    rows = []
    for k in sorted(by):
        rs = by[k]
        st = [r["n_stays"] for r in rs]
        leads = [r["class"].get("lead", 0) for r in rs]
        nsup = [r["class"].get("suppressors") for r in rs]
        rows.append([k[0], k[1], len(rs), rs[0]["class"]["targets"], rs[0]["class"]["sites"],
                     min(st), fmt(mean(st)), max(st), min(leads), max(leads), min(nsup), max(nsup)])
    return ["strikers", "fleet", "plans", "targets", "sites", "stays min", "stays mean", "stays max",
            "lead min", "lead max", "assets min", "assets max"], rows


def table2(runs):
    rows, keys = [], sorted(set(cls_key(r) for r in runs))
    for k in keys + [("all", "")]:
        for m in MODELS:
            rs = [r for r in runs if r["model"] == m and (k[0] == "all" or cls_key(r) == k)]
            if not rs:
                continue
            gaps, gsel, lp_inf, n_inf = [], [], 0, 0
            for r in rs:
                lp = r.get("lp") or {}
                if r["status"] == "optimal" and r.get("obj") and lp.get("obj") is not None and abs(r["obj"]) > 1e-9:
                    g = 100.0 * abs(r["obj"] - lp["obj"]) / abs(r["obj"])
                    (gsel if r["variant"] == "select" else gaps).append(g)
                if r["status"] in INFEAS:
                    n_inf += 1
                    lp_inf += lp.get("status") in INFEAS
            rows.append(["all" if k[0] == "all" else k[0], k[1], MODEL_NAME[m], len(rs), sum(solved(r) for r in rs),
                         sum(r["status"] == "time limit" for r in rs), fmt(sgm([r["runtime"] or 0.0 for r in rs]), 2),
                         fmt(max(r["runtime"] or 0.0 for r in rs), 1), fmt(mean([r.get("nodes") for r in rs]), 0),
                         fmt(mean(gaps), 1), fmt(mean(gsel), 1), "%d of %d" % (lp_inf, n_inf),
                         fmt(mean([r.get("bin_vars") for r in rs]), 0), fmt(mean([r.get("constrs") for r in rs]), 0)])
    return ["strikers", "fleet", "model", "runs", "solved", "time limit", "time sgm s", "time max s", "nodes mean",
            "LP gap mean % (cost variants)", "LP gap mean % (selection)", "LP proves infeasibility",
            "binaries mean", "constraints mean"], rows


def coverage(runs, extra=()):
    """{(instance, variant): (feasible True/False/None, best cost, hold, class key)}
    extra: rerun records (longer time limit) that may settle a status or prove an optimal cost."""
    out = {}
    for r in list(runs) + list(extra):
        key = (r["instance"], r["variant"])
        cur = out.get(key, [None, None, None, cls_key(r)])
        if r["status"] == "optimal":
            cur[0] = True
            if cur[1] is None or r["obj"] < cur[1]:
                cur[1] = r["obj"]
                cur[2] = (r.get("solution") or {}).get("hold_total")
        elif r["status"] in INFEAS and cur[0] is None:
            cur[0] = False
        out[key] = cur
    for i in set(k[0] for k in out):                       # monotone in the hold bound
        seq = [out.get((i, v)) for v in VARIANTS]
        for n, c in enumerate(seq):
            if c is not None and c[0] is None:
                if any(d is not None and d[0] is True for d in seq[:n]):
                    c[0] = True
                elif any(d is not None and d[0] is False for d in seq[n + 1:]):
                    c[0] = False
    return out


def table3(runs, extra=()):
    cov = coverage(runs, extra)
    rows = []
    for k in sorted(set(cls_key(r) for r in runs)):
        for v in VARIANTS:
            cells = [c for (i, vv), c in cov.items() if vv == v and c[3] == k]
            n = len(cells)
            yes = sum(1 for c in cells if c[0] is True)
            unk = sum(1 for c in cells if c[0] is None)
            costs = [c[1] for c in cells if c[0] is True and c[1] is not None]
            holds = [c[2] for c in cells if c[0] is True and c[2] is not None]
            rows.append([k[0], k[1], BOUND[v], n, yes, unk, fmt(100.0 * yes / n if n else None, 0),
                         fmt(mean(costs), 2), len(costs), fmt(mean(holds), 1) if v != "fixed" else ""])
    return ["strikers", "fleet", "hold bound min", "plans", "coverable", "unknown", "coverable %",
            "cost mean", "plans with proven optimal cost", "hold used mean min"], rows


def table4(runs):
    best = {}
    for r in runs:
        if r["variant"] == "select" and r["status"] == "optimal" and r.get("solution"):
            s = r["solution"]
            cur = best.get(r["instance"])
            if cur is None or r["obj"] > cur[0]:
                best[r["instance"]] = (r["obj"], s.get("value_flown", 0), s.get("value_plan", 0),
                                       len(s.get("flown", [])), r["_R"], cls_key(r))
    rows = []
    for k in sorted(set(v[5] for v in best.values())):
        vs = [v for v in best.values() if v[5] == k]
        kept = [100.0 * v[1] / v[2] for v in vs if v[2]]
        rows.append([k[0], k[1], len(vs), fmt(mean(kept), 1), fmt(min(kept) if kept else None, 1),
                     sum(1 for x in kept if x >= 100.0 - 1e-9), fmt(mean([100.0 * (v[4] - v[3]) / v[4] for v in vs]), 1)])
    return ["strikers", "fleet", "plans", "value kept mean %", "value kept min %", "plans keeping all value",
            "sorties cancelled mean %"], rows


def table5(runs, inst_dir):
    avail = {}
    for p in glob.glob(os.path.join(inst_dir, "B_*.json")):
        with open(p) as f:
            inst = json.load(f)
        avail[inst["name"]] = {kind: sum(1 for v in inst["suppressors"] if v["kind"] == kind) for kind, _ in KINDS}
    rows = []
    groups = sorted(set((r["_mix"], r["_level"]) for r in runs))
    for v in ["fixed", "delay15", "select"]:
        for g in groups:
            rs = [r for r in runs if r["model"] == "ti" and r["variant"] == v and (r["_mix"], r["_level"]) == g
                  and r["status"] == "optimal" and r.get("solution")]
            if not rs:
                continue
            row = [v, g[0], g[1], len(rs)]
            for kind, short in KINDS:
                used = [r["solution"]["assets_by_kind"].get(kind, 0) for r in rs]
                av = [avail.get(r["instance"], {}).get(kind, 0) for r in rs]
                row += [fmt(mean(used), 2), fmt(100.0 * sum(used) / sum(av) if sum(av) else None, 0)]
            rows.append(row)
    head = ["variant", "fleet mix", "fleet", "plans solved"]
    for _, short in KINDS:
        head += [short + " used mean", short + " used % of available"]
    return head, rows


def table6(runs, extra=()):
    """Effect of holds on the same plans (see hold effect above)."""
    cov = coverage(runs, extra)
    rows = []
    for k in sorted(set(cls_key(r) for r in runs)):
        insts = sorted(set(i for (i, v), c in cov.items() if c[3] == k))
        for v in VARIANTS[1:]:
            red, cheaper, new = [], 0, 0
            for i in insts:
                f, d = cov.get((i, "fixed")), cov.get((i, v))
                if f is None or d is None:
                    continue
                if f[0] is False and d[0] is True:
                    new += 1
                if f[1] is not None and d[1] is not None:
                    red.append(100.0 * (f[1] - d[1]) / f[1])
                    cheaper += d[1] < f[1] - 1e-6
            rows.append([k[0], k[1], BOUND[v], len(red), fmt(mean(red), 1), cheaper, new])
    return ["strikers", "fleet", "hold bound min", "plans compared", "cost reduction mean %",
            "plans cheaper", "plans newly coverable"], rows


def agreement(runs):
    """(runs optimal in both models, of these equal within 1e-6, feasibility disagreements)."""
    by = {(r["instance"], r["variant"], r["model"]): r for r in runs}
    both = equal = dis = 0
    for (i, v, m), a in by.items():
        b = by.get((i, v, "ti"))
        if m != "slot" or b is None:
            continue
        if a["status"] == "optimal" and b["status"] == "optimal":
            both += 1
            equal += abs(a["obj"] - b["obj"]) <= 1e-6
        elif (a["status"] == "optimal" and b["status"] in INFEAS) or \
                (b["status"] == "optimal" and a["status"] in INFEAS):
            dis += 1
    return both, equal, dis


def md_table(head, rows):
    out = ["| " + " | ".join(head) + " |", "|" + "---|" * len(head)]
    for r in rows:
        out.append("| " + " | ".join(str(x) for x in r) + " |")
    return "\n".join(out)


def tables_md(t2, t3, t4, t5, t6):
    """Paper versions of Tables 3 to 7, built from the same rows as the CSV files."""
    M = {"continuous-time model": "Continuous-time", "time-indexed model": "Time-indexed"}
    L = ["# Paper B tables (generated by code/paperB_tables.py, do not edit by hand)", ""]
    L.append("**Table 3.** Formulations by class: runs solved within 600 s (optimal or proven infeasible), "
             "shifted geometric mean time, mean nodes, mean LP gap and mean number of binary variables.")
    L.append("")
    rows = [[("All" if r[0] == "all" else r[0]), r[1], M[r[2]], "%s of %s" % (r[4], r[3]), r[6], r[8], r[9],
             r[10], r[12]] for r in t2[1]]
    L.append(md_table(["Strikers", "Fleet", "Formulation", "Solved", "Time (s)", "Nodes",
                       "LP gap, cost (%)", "LP gap, selection (%)", "Binaries"], rows))
    L += ["", "**Table 4.** Plans coverable with times fixed and with holds of at most 5, 10 and 15 minutes per "
          "striker (% of the 15 plans in each class).", ""]
    cls = []
    for r in t3[1]:
        if (r[0], r[1]) not in cls:
            cls.append((r[0], r[1]))
    rows = []
    for c in cls:
        cells = {r[2]: r for r in t3[1] if (r[0], r[1]) == c}
        rows.append([c[0], c[1]] + [cells[b][6] + ("*" if cells[b][5] else "") for b in (0, 5, 10, 15)])
    L.append(md_table(["Strikers", "Fleet", "Fixed", "5 min", "10 min", "15 min"], rows))
    if any(r[5] for r in t3[1]):
        L.append("")
        L.append("\\* includes plans not settled within the time limit, counted as not coverable.")
    L += ["", "**Table 5.** Effect of holds on the plans with a proven optimal cost both with times fixed and "
          "with holds: mean cost reduction (hold penalty included) and plans that become coverable.", ""]
    rows = [[r[0], r[1], r[2], r[3], r[4], r[5], r[6]] for r in t6[1]]
    L.append(md_table(["Strikers", "Fleet", "Hold bound (min)", "Plans compared", "Cost reduction (%)",
                       "Plans cheaper", "Newly coverable"], rows))
    L += ["", "**Table 6.** Sortie selection: share of the plan value kept and of the sorties cancelled.", ""]
    rows = [[r[0], r[1], r[3], r[4], "%s of %s" % (r[5], r[2]), r[6]] for r in t4[1]]
    L.append(md_table(["Strikers", "Fleet", "Value kept, mean (%)", "Value kept, lowest (%)",
                       "Plans keeping all value", "Sorties cancelled (%)"], rows))
    L += ["", "**Table 7.** Assets used in optimal solutions of the time-indexed formulation, as a share of the "
          "assets available, with times fixed and with sortie selection.", ""]
    rows = [[{"fixed": "Fixed", "select": "Selection"}[r[0]], r[1], r[2], r[3], r[5], r[7], r[9]]
            for r in t5[1] if r[0] in ("fixed", "select")]
    L.append(md_table(["Variant", "Fleet mix", "Fleet", "Plans", "Manned (%)", "Jammer (%)", "Decoy (%)"], rows))
    return "\n".join(L) + "\n"


# ------------------------------------------------------------------ figures
def _style(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(INK2)
    ax.tick_params(colors=INK2, labelsize=8)
    ax.grid(True, color=GRID, lw=0.6)
    ax.set_axisbelow(True)


def fig_profile(runs, path, tlim):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(5.2, 3.2))
    grid = [10 ** (e / 20.0) for e in range(-40, 1 + int(20 * math.log10(tlim)))]
    style = {"ti": ("-", "o"), "slot": ("--", "s")}
    for m in MODELS:
        rs = [r for r in runs if r["model"] == m]
        if not rs:
            continue
        times = sorted((r["runtime"] or 0.0) for r in rs if solved(r))
        ys = [100.0 * sum(1 for t in times if t <= g) / len(rs) for g in grid]
        ax.plot(grid, ys, color=COL[m], lw=2, ls=style[m][0], marker=style[m][1], markevery=10, ms=5,
                label=FIG_NAME[m])
        ax.annotate(FIG_NAME[m], (grid[-1], ys[-1]), xytext=(4, 0), textcoords="offset points",
                    fontsize=8, color=INK, va="center")
    ax.set_xscale("log")
    ax.set_xlim(grid[0], tlim)
    ax.set_ylim(0, 102)
    ax.set_xlabel("solution time (s)", fontsize=9, color=INK)
    ax.set_ylabel("runs solved within the time (%)", fontsize=9, color=INK)
    _style(ax)
    fig.tight_layout()
    for ext in ("png", "pdf"):
        fig.savefig(path + "." + ext, dpi=200)
    plt.close(fig)


def fig_coverage(runs, path, extra=()):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    cov = coverage(runs, extra)
    Rs = sorted(set(r["_R"] for r in runs))
    fig, axes = plt.subplots(1, len(Rs), figsize=(2.3 * len(Rs) + 0.6, 2.8), sharey=True)
    if len(Rs) == 1:
        axes = [axes]
    style = {"base": ("-", "o"), "scaled": ("--", "s")}
    for ax, R in zip(axes, Rs):
        for lvl in ("base", "scaled"):
            ys = []
            for v in VARIANTS:
                cells = [c for (i, vv), c in cov.items() if vv == v and c[3] == (R, lvl)]
                ys.append(100.0 * sum(1 for c in cells if c[0] is True) / len(cells) if cells else None)
            if all(y is None for y in ys):
                continue
            xs = [BOUND[v] for v in VARIANTS]
            ax.plot(xs, ys, color=COL[lvl], lw=2, ls=style[lvl][0], marker=style[lvl][1], ms=6,
                    label="%s fleet" % lvl)
        ax.set_title("%d strikers" % R, fontsize=9, color=INK)
        ax.set_xticks([BOUND[v] for v in VARIANTS])
        ax.set_xlabel("hold bound (min)", fontsize=8, color=INK)
        ax.set_ylim(0, 105)
        _style(ax)
    axes[0].set_ylabel("plans coverable (%)", fontsize=9, color=INK)
    h, lab = axes[-1].get_legend_handles_labels()
    if not h:
        h, lab = axes[0].get_legend_handles_labels()
    fig.legend(h, lab, fontsize=8, frameon=False, loc="upper center", ncol=2, bbox_to_anchor=(0.5, 1.02))
    fig.tight_layout(rect=(0, 0, 1, 0.92))
    for ext in ("png", "pdf"):
        fig.savefig(path + "." + ext, dpi=200)
    plt.close(fig)


def fig_map(inst_path, path, width=300.0):
    """Example instance with its plan, mirrored so that the base is in the east."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    with open(inst_path) as f:
        inst = json.load(f)
    # instance files shared with the paper are already mirrored (code/mirror_instances.py, field "mirrored")
    X = (lambda x: x) if inst.get("mirrored") else (lambda x: width - x)
    fig, ax = plt.subplots(figsize=(6.4, 3.9))
    for s in inst["sites"]:
        c, r = s["center"], s["radius"]
        ax.add_patch(plt.Circle((X(c[0]), c[1]), r, fill=True, alpha=0.10, color="#e34948", lw=0))
        ax.add_patch(plt.Circle((X(c[0]), c[1]), r, fill=False, ls="-" if s["class"] == "long" else "--",
                                color="#e34948", lw=1))
        ax.annotate(s["id"], (X(c[0]), c[1] + r), xytext=(0, 2), textcoords="offset points", ha="center",
                    va="bottom", fontsize=7, color="#b8302f")
        st = inst["stations"][s["id"]]
        ax.plot(X(st[0]), st[1], marker="^", ms=5, color=INK2, ls="none")
    P = inst["positions"]
    ax.plot(X(P["B"][0]), P["B"][1], marker="s", ms=8, color=INK, ls="none")
    ax.annotate("base", (X(P["B"][0]), P["B"][1]), xytext=(-6, 6), textcoords="offset points", fontsize=8,
                ha="right", color=INK)
    cols = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300"]
    for n, (rid, q) in enumerate(sorted(inst.get("plan", {}).items())):
        pts = []
        for aid in q["arcs"]:
            a, b = aid.split(":")[-1].split("#")[0].split(">")
            a = "B" if a.startswith("o_") else a
            b = "B" if b.startswith("d_") else b
            pts += [P[a], P[b]]
        if pts:
            ax.plot([X(p[0]) for p in pts], [p[1] for p in pts], color=cols[n % len(cols)], lw=1.5, label=("R" + rid[1:]) if rid.startswith("S") else rid)  # strikers R1, R2, ... as in the paper (ids S1, ... in the files)
    for t in inst["targets"]:
        p = P[t["id"]]
        ax.plot(X(p[0]), p[1], marker="o", ms=5, color=INK, ls="none", mfc="white", mew=1.2)
        ax.annotate(t["id"], (X(p[0]), p[1]), xytext=(3, 3), textcoords="offset points", fontsize=6, color=INK2)
    ax.set_xlim(-10, width + 10)
    ax.set_ylim(-10, 210)
    ax.set_aspect("equal")
    ax.set_xlabel("km", fontsize=8, color=INK)
    ax.set_ylabel("km", fontsize=8, color=INK)
    _style(ax)
    ax.grid(False)
    lg = ax.legend(fontsize=7, frameon=False, loc="upper left", bbox_to_anchor=(1.0, 1.0), title="strikers",
                   title_fontsize=7)
    ax.add_artist(lg)
    from matplotlib.lines import Line2D
    key = [Line2D([], [], color="#e34948", lw=1, ls="-"), Line2D([], [], color="#e34948", lw=1, ls="--"),
           Line2D([], [], marker="^", ms=5, color=INK2, ls="none")]
    ax.legend(key, ["long-range zone", "short-range zone", "suppression station"], fontsize=7, frameon=False,
              loc="lower left", bbox_to_anchor=(1.0, 0.0))
    fig.tight_layout()
    for ext in ("png", "pdf"):
        fig.savefig(path + "." + ext, dpi=200, bbox_inches="tight")
    plt.close(fig)



def fig_example(ex_path, path):
    """Worked example of Section 2.6, read from results/paperB_example.json.
    (a) Schematic map (the example has flight times only, so positions are chosen for the drawing): routes of
    the strikers with the minutes they enter and leave each zone, stations, the path and windows of the manned
    SEAD aircraft in the schedule with holds, the unused drones. (b) to (d) Zone stays and windows over time:
    times fixed (the best attempt and the minutes it cannot cover, both formulations prove infeasibility),
    sortie selection and holds of at most 5 min (optimal windows of the time-indexed formulation)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle, Patch, Circle
    from matplotlib.lines import Line2D
    with open(ex_path) as f:
        ex = json.load(f)
    inst, runs = ex["instance"], ex["runs"]
    name = lambda r: "R" + r[1:] if r.startswith("S") else r          # strikers R1, R2 as in the paper
    manned = [a for a in inst["suppressors"] if a["manned"]][0]
    drones = [a for a in inst["suppressors"] if not a["manned"]]
    Lm = manned["window"]
    fly = {}
    for a, b, t in manned["site_to_site"]:
        fly[(a, b)] = fly[(b, a)] = t
    sites = [s["id"] for s in inst["sites"]]
    strikers = [r["id"] for r in inst["strikers"]]
    scol = dict(zip(strikers, ["#2a78d6", "#eb6834"]))
    WCOL, RED = "#1baf7a", "#e34948"
    stays = [(s, b, e, r) for s, b, e, r in ex["stays"]]
    hsol = runs["ti_delay5"]["solution"]
    hold = hsol["hold"]
    fmt = lambda x: "%g" % x
    fig = plt.figure(figsize=(6.4, 8.0))
    gs = fig.add_gridspec(4, 1, height_ratios=[2.1, 1, 1, 1], hspace=0.5)
    axm = fig.add_subplot(gs[0])
    axes = [fig.add_subplot(gs[i]) for i in (1, 2, 3)]
    for ax in axes[1:]:
        ax.sharex(axes[0])

    # ---------------- (a) schematic map, base in the east as in the map of the results
    P = {"B": (100, 36), "T1": (14, 64), "T3": (6, 36), "T2": (14, 7)}
    Z = {sites[0]: ((53, 53), 11), sites[1]: ((50, 25), 12)}                 # schematic zones
    ST = {sites[0]: (66, 61), sites[1]: (64, 12)}                             # schematic stations
    for s, (c, r) in Z.items():
        axm.add_patch(Circle(c, r, fc=RED, alpha=0.10, lw=0))
        axm.add_patch(Circle(c, r, fill=False, ec=RED, lw=1))
    axm.text(53, 64.5, "zone of " + sites[0], ha="center", va="bottom", fontsize=7, color="#b8302f")
    axm.text(37.5, 25, "zone of " + sites[1], ha="right", va="center", fontsize=7, color="#b8302f")
    routes = {strikers[0]: ["B", "T1", "T3", "B"], strikers[1]: ["B", "T2", (35, -4), (96, -4), "B"]}
    for r, pts in routes.items():
        xy = [P[p] if isinstance(p, str) else p for p in pts]
        axm.plot([p[0] for p in xy], [p[1] for p in xy], color=scol[r], lw=1.6, zorder=3)
        for a, b in zip(xy[:-1], xy[1:]):                                   # direction marks
            m = (0.62 * a[0] + 0.38 * b[0], 0.62 * a[1] + 0.38 * b[1])
            axm.annotate("", xy=(m[0] + (b[0] - a[0]) * 0.03, m[1] + (b[1] - a[1]) * 0.03), xytext=m,
                         arrowprops=dict(arrowstyle="-|>", color=scol[r], lw=0, mutation_scale=9), zorder=3)
    for t_ in ("T1", "T2", "T3"):
        axm.plot(*P[t_], marker="o", ms=6, color=INK, mfc="white", mew=1.2, ls="none", zorder=4)
        axm.text(P[t_][0] - 2.5, P[t_][1], t_, ha="right", va="center", fontsize=7.5, color=INK)
    axm.plot(*P["B"], marker="s", ms=9, color=INK, ls="none", zorder=5)
    axm.text(P["B"][0] + 3.5, P["B"][1], "base", ha="left", va="center", fontsize=8, color=INK)
    # minutes at which each striker enters and leaves a zone (the plan)
    lab = {(sites[0], strikers[0]): (41, 49, "right"), (sites[1], strikers[0]): (43, 38.6, "right"),
           (sites[1], strikers[1]): (47, 1.0, "center")}
    for s, b, e, r in stays:
        x, y, ha = lab[(s, r)]
        axm.text(x, y, "%s in zone %s to %s" % (name(r), fmt(b), fmt(e)), ha=ha, va="center", fontsize=6.8,
                 color=INK, zorder=6)
    # stations, path and windows of the manned aircraft (schedule with holds)
    order = []
    for s, _, b, e in hsol["windows"]:
        if s not in order:
            order.append(s)
    path_pts = [P["B"]] + [ST[s] for s in order] + [P["B"]]
    axm.plot([p[0] for p in path_pts], [p[1] for p in path_pts], color=WCOL, lw=1.4, ls=(0, (4, 2)), zorder=2)
    legs = [manned["base_to_site"][order[0]]] + [fly[(a, b)] for a, b in zip(order[:-1], order[1:])] + \
           [manned["site_to_base"][order[-1]]]
    for (x, y), tt in zip([(85, 51), (66.5, 42), (84, 21)], legs):
        axm.text(x, y, "%s min" % fmt(tt), fontsize=6.5, color=INK2, ha="left", va="center")
    spos = {sites[0]: (69.5, 66, "left", "center"), sites[1]: (67, 9.5, "left", "top")}
    for s in sites:
        axm.plot(*ST[s], marker="^", ms=7, color=INK2, ls="none", zorder=5)
        ws = [(b, e) for ss, _, b, e in hsol["windows"] if ss == s]
        x, y, ha, va = spos[s]
        axm.text(x, y, "station %s\nwindow%s %s" % (s, "s" if len(ws) > 1 else "",
                 "\nand ".join("%s to %s" % (fmt(b), fmt(e)) for b, e in ws)), fontsize=6.8, color=INK,
                 ha=ha, va=va, linespacing=1.15)
    held = [(name(r), d) for r, d in hold.items() if d > 0]
    note = "".join("%s holds %s min before launch,\nso it is in zone %s from %s to %s\n\n" %
                   (nm, fmt(d), s, fmt(b + d), fmt(e + d)) for nm, d in held
                   for s, b, e, r in stays if name(r) == nm)
    note += "not used:\n" + "\n".join("%s, window %s min" % (dd["kind"], fmt(dd["window"])) for dd in drones)
    axm.text(106, 30, note, fontsize=6.5, color=INK2, ha="left", va="top")
    axm.set_xlim(0, 160)
    axm.set_ylim(-8, 70)
    axm.set_aspect("equal")
    axm.axis("off")
    keys = [Line2D([], [], color=scol[r], lw=1.6, label="route of " + name(r)) for r in strikers]
    keys.append(Line2D([], [], color=WCOL, lw=1.4, ls=(0, (4, 2)), label="manned SEAD aircraft"))
    keys.append(Line2D([], [], marker="^", color=INK2, ls="none", ms=6, label="suppression station"))
    axm.legend(handles=keys, fontsize=7, frameon=False, loc="upper right", bbox_to_anchor=(1.0, 1.0))
    axm.set_title("(a) Plan and schedule with holds of at most 5 minutes (schematic, not to scale)",
                  loc="left", fontsize=8.5, color=INK)

    # ---------------- (b) to (d) timelines
    Y = {s: len(sites) - 1 - n for n, s in enumerate(sites)}
    H = 0.30

    def stay(ax, s, b, e, r, ghost=False, label=True):
        y = Y[s] + 0.19
        if ghost:
            ax.add_patch(Rectangle((b, y - H / 2), e - b, H, fill=False, ec=INK2, lw=0.9, ls=(0, (3, 2))))
        else:
            ax.add_patch(Rectangle((b, y - H / 2), e - b, H, fc=scol[r], ec="white", lw=1.0))
        if label:
            ax.text(e + 0.8, y, name(r), va="center", ha="left", fontsize=7.5, color=INK)

    def window(ax, s, b, e, dashed=False):
        y = Y[s] - 0.19
        if dashed:
            ax.add_patch(Rectangle((b, y - H / 2), e - b, H, fc="white", ec=WCOL, lw=1.2, ls=(0, (3, 2))))
        else:
            ax.add_patch(Rectangle((b + 0.15, y - H / 2), e - b - 0.3, H, fc=WCOL, ec="white", lw=1.0))

    ax = axes[0]
    s_first = [x for x in stays if x[0] == sites[0]][0]
    w_end = s_first[2]                       # earliest close of a window that covers the stay at the first site
    w_beg = w_end - Lm
    assert w_beg <= s_first[1]
    arr = w_end + fly[(sites[0], sites[1])]  # earliest arrival at the second site
    for s, b, e, r in stays:
        stay(ax, s, b, e, r)
    window(ax, sites[0], w_beg, w_end)
    window(ax, sites[1], arr, arr + Lm, dashed=True)
    late = [x for x in stays if x[0] == sites[1] and x[1] < arr][0]
    ys, yw = Y[sites[1]] + 0.19, Y[sites[1]] - 0.19
    ax.add_patch(Rectangle((late[1], ys - H / 2), arr - late[1], H, fill=False, ec=RED, lw=1.4, hatch="////"))
    ax.plot([w_end, w_end], [Y[sites[0]] - 0.19 - H / 2, yw], color=INK2, lw=0.8, ls=":")
    ax.annotate("", xy=(arr, yw), xytext=(w_end, yw), arrowprops=dict(arrowstyle="->", color=INK2, lw=0.9))
    ax.text(w_end - 0.8, yw, "flight %s min" % fmt(fly[(sites[0], sites[1])]), fontsize=7, color=INK2,
            ha="right", va="center")
    ax.text(late[1], ys + H / 2 + 0.05, "%s min not covered" % fmt(arr - late[1]), fontsize=7, color=INK,
            ha="left", va="bottom")
    ax.text(arr + Lm + 0.8, yw, "earliest window at %s" % sites[1], fontsize=7, color=INK2, va="center",
            ha="left")
    ax.set_title("(b) Times fixed: no schedule covers every stay", loc="left", fontsize=8.5, color=INK)

    ax = axes[1]
    sol = runs["ti_select"]["solution"]
    for s, b, e, r in stays:
        stay(ax, s, b, e, r, ghost=r not in sol["flown"], label=r in sol["flown"])
        if r not in sol["flown"]:
            ax.text(e + 0.8, Y[s] + 0.19, name(r) + " cancelled", va="center", ha="left", fontsize=7.5, color=INK2)
    for s, _, b, e in sol["windows"]:
        window(ax, s, b, e)
    ax.set_title("(c) Sortie selection: %s cancelled" % ", ".join(name(r) for r in strikers if r not in sol["flown"]),
                 loc="left", fontsize=8.5, color=INK)

    ax = axes[2]
    for s, b, e, r in stays:
        d = hold.get(r, 0.0)
        if d > 0:
            stay(ax, s, b, e, r, ghost=True, label=False)
            ax.annotate("", xy=(b + d, Y[s] + 0.19 + H / 2 + 0.08), xytext=(b, Y[s] + 0.19 + H / 2 + 0.08),
                        arrowprops=dict(arrowstyle="->", color=INK, lw=0.9))
            ax.text(b - 0.8, Y[s] + 0.19 + H / 2 + 0.08, "hold %s min" % fmt(d), fontsize=7, color=INK, ha="right",
                    va="center")
        stay(ax, s, b + d, e + d, r)
    for s, _, b, e in hsol["windows"]:
        window(ax, s, b, e)
    held = [(name(r), fmt(d)) for r, d in hold.items() if d > 0][0]
    ax.set_title("(d) Holds of at most 5 minutes: %s holds %s minutes" % held, loc="left", fontsize=8.5, color=INK)

    for ax in axes:
        _style(ax)
        ax.grid(True, axis="x", color=GRID, lw=0.6)
        ax.grid(False, axis="y")
        ax.set_ylim(-0.55, len(sites) - 0.45)
        ax.set_yticks([Y[s] for s in sites])
        ax.set_yticklabels(["site " + s for s in sites], fontsize=8, color=INK)
        ax.tick_params(axis="y", length=0)
    for ax in axes[:-1]:
        ax.tick_params(axis="x", labelbottom=False)
    axes[-1].set_xlim(30, 102)
    axes[-1].set_xticks(range(30, 101, 10))
    axes[-1].set_xlabel("time (min)", fontsize=8, color=INK)
    keys = [Patch(fc=scol[r], ec="white", label="zone stay of " + name(r)) for r in strikers]
    keys.append(Patch(fc=WCOL, ec="white", label="window of the manned SEAD aircraft"))
    fig.legend(handles=keys, fontsize=7.5, frameon=False, loc="lower center", ncol=3, bbox_to_anchor=(0.5, 0.0))
    fig.subplots_adjust(left=0.11, right=0.98, top=0.975, bottom=0.075)
    for ext in ("png", "pdf"):
        fig.savefig(path + "." + ext, dpi=200)
    plt.close(fig)


# ------------------------------------------------------------------ summary in words
def stay_lengths(runs):
    """Lengths of the zone stays of the base-fleet plans (each plan once; scaled fleets share the plans)."""
    L = []
    for r in runs:
        if r["model"] == "ti" and r["variant"] == "fixed" and r["_level"] == "base":
            L += [h[2] - h[1] for h in r.get("stays", [])]
    return sorted(L)


def example_lines(runs, name):
    """Results of every variant on the plan drawn in the map figure."""
    out = []
    for v in VARIANTS[:1] + ["select"] + VARIANTS[1:]:
        rs = {r["model"]: r for r in runs if r["instance"] == name and r["variant"] == v}
        parts = []
        for m in MODELS:
            r = rs.get(m)
            if r is None:
                continue
            s = r.get("solution") or {}
            txt = "%s %s" % (m, r["status"])
            if r["status"] == "optimal":
                txt += " obj %.2f, assets %s" % (r["obj"], s.get("assets_by_kind"))
                if s.get("hold_total"):
                    txt += ", hold total %.0f min" % s["hold_total"]
                if "value_flown" in s:
                    txt += ", value kept %s of %s" % (s["value_flown"], s["value_plan"])
            parts.append(txt)
        out.append("- %s: %s." % (v, "; ".join(parts)))
    return out


def rerun_lines(runs, extra):
    """The reruns at 3600 s against the runs at 600 s of both formulations."""
    if not extra:
        return []
    by = {(r["instance"], r["variant"], r["model"]): r for r in runs}
    L, st = [], {}
    for r in sorted(extra, key=lambda x: x["instance"]):
        st[r["status"]] = st.get(r["status"], 0) + 1
        inc = [by[(r["instance"], r["variant"], m)].get("obj") for m in MODELS
               if (r["instance"], r["variant"], m) in by and by[(r["instance"], r["variant"], m)].get("obj") is not None]
        best = (max(inc) if r.get("select") else min(inc)) if inc else None
        txt = "- %s %s (%s, %.0f s): %s" % (r["instance"], r["variant"], r["model"], r.get("runtime") or 0, r["status"])
        if r.get("obj") is not None:
            txt += ", objective %.2f, bound %.2f, gap %.1f%%" % (r["obj"], r["bound"], 100.0 * (r.get("gap") or 0.0))
        if best is not None and r.get("obj") is not None:
            txt += ", best solution at 600 s %.2f (%s)" % (best, "the same" if abs(best - r["obj"]) <= 1e-6 else "improved")
        elif best is None:
            txt += ", no solution at 600 s"
        L.append(txt + ".")
    head = "- %d reruns: %s." % (len(extra), ", ".join("%d %s" % (n, k) for k, n in sorted(st.items())))
    return [head] + L


def summary(runs, t2, t3, t4, t5, t6=None, example=None, extra=()):
    L = ["# Paper B results summary (generated by code/paperB_tables.py, do not edit by hand)", ""]
    n_inst = len(set(r["instance"] for r in runs))
    L.append("Runs read: %d on %d plans. Settings: %s." % (len(runs), n_inst, runs[0].get("settings") if runs else ""))
    L.append("")
    L.append("## Formulations (all classes)")
    for row in t2[1]:
        if row[0] == "all":
            L.append("- %s: %s of %s runs solved, %s at the time limit, shifted geometric mean time %s s, "
                     "longest %s s, mean LP gap %s%% in the cost variants and %s%% in sortie selection, "
                     "LP relaxation proves infeasibility in %s infeasible runs."
                     % (row[2], row[4], row[3], row[5], row[6], row[7], row[9] or "-", row[10] or "-", row[11]))
    sl = [r for r in runs if r["model"] == "slot"]
    ti = {(r["instance"], r["variant"]): r for r in runs if r["model"] == "ti"}
    faster = slower = 0
    for r in sl:
        o = ti.get((r["instance"], r["variant"]))
        if o and solved(r) and solved(o):
            faster += (o["runtime"] or 0) < (r["runtime"] or 0)
            slower += (o["runtime"] or 0) > (r["runtime"] or 0)
    L.append("- Pairs solved by both: time-indexed faster in %d, continuous-time faster in %d." % (faster, slower))
    both, equal, dis = agreement(runs)
    L.append("- Agreement: %d runs optimal in both formulations, equal optimal values in %d of them; "
             "%d runs proven infeasible by one formulation and solved to optimality by the other."
             % (both, equal, dis))
    sl_ = stay_lengths(runs)
    if sl_:
        n = len(sl_)
        L.append("")
        L.append("## Zone stays (base-fleet plans, each plan once)")
        L.append("- %d stays: %d (%.0f%%) no longer than 5 min (a decoy window), %d no longer than 12 min (a jammer "
                 "window), %d no longer than 20 min (a manned window), median %.0f min, longest %.0f min."
                 % (n, sum(x <= 5 for x in sl_), 100.0 * sum(x <= 5 for x in sl_) / n, sum(x <= 12 for x in sl_),
                    sum(x <= 20 for x in sl_), sl_[n // 2] if n % 2 else 0.5 * (sl_[n // 2 - 1] + sl_[n // 2]),
                    sl_[-1]))
    L.append("")
    L.append("## Coverage of zone-blind plans")
    for row in t3[1]:
        how = "times fixed" if row[2] == 0 else "holds up to %s min" % row[2]
        L.append("- %s strikers, %s fleet, %s: %s of %s plans coverable (%s%%)%s, mean cost %s."
                 % (row[0], row[1], how, row[4], row[3], row[6] or "-",
                    ", %s not settled" % row[5] if row[5] else "",
                    ("%s over %s plans with a proven optimum" % (row[7], row[8])) if row[7] else "-"))
    rl = rerun_lines(runs, extra)
    if rl:
        L.append("")
        L.append("## Reruns at 3600 s of the runs unsolved by both formulations (time-indexed formulation)")
        L += rl
        L.append("- The reruns settle coverage and proven optimal costs below and in Tables 3 and 4. "
                 "The formulation comparison above stays at 600 s.")
    if t6:
        L.append("")
        L.append("## Effect of holds on the same plans (against times fixed)")
        for row in t6[1]:
            L.append("- %s strikers, %s fleet, holds up to %s min: cost %s%% lower on average over %s plans with "
                     "both optima, %s plans cheaper, %s plans newly coverable."
                     % (row[0], row[1], row[2], row[4] or "-", row[3], row[5], row[6]))
    L.append("")
    L.append("## Sortie selection")
    for row in t4[1]:
        L.append("- %s strikers, %s fleet: mean value kept %s%% (lowest %s%%), %s of %s plans keep all value."
                 % (row[0], row[1], row[3], row[4], row[5], row[2]))
    L.append("")
    L.append("## Assets used (time-indexed model, optimal runs)")
    for row in t5[1]:
        L.append("- %s, %s mix, %s fleet (%s plans): manned %s (%s%% of available), jammer %s (%s%%), decoy %s (%s%%)."
                 % tuple(row[:4] + row[4:]))
    if example:
        L.append("")
        ns = [r["n_stays"] for r in runs if r["instance"] == example and r.get("n_stays") is not None]
        L.append("## Example plan of the map figure (%s, %s zone stays)" % (example, ns[0] if ns else "?"))
        L += example_lines(runs, example)
    return "\n".join(L) + "\n"


def main(res=RES, inst=INST, out=OUT):
    runs = load_runs(res)
    extra = load_runs(RES_LONG) if os.path.isdir(RES_LONG) else []
    if not runs:
        print("No runs found in " + res)
        return
    figs = os.path.join(out, "figures")
    for d in (out, figs):
        if not os.path.isdir(d):
            os.makedirs(d)
    t1, t2, t3, t4, t5 = table1(runs, inst), table2(runs), table3(runs, extra), table4(runs), table5(runs, inst)
    t6 = table6(runs, extra)
    for name, t in (("table1_instances", t1), ("table2_formulations", t2), ("table3_coverage", t3),
                    ("table4_selection", t4), ("table5_assets", t5), ("table6_holds", t6)):
        write_csv(os.path.join(out, name + ".csv"), t[0], t[1])
    tlim = max((r.get("settings") or {}).get("time_limit", 600) for r in runs)
    fig_profile(runs, os.path.join(figs, "fig_profile"), tlim)
    fig_coverage(runs, os.path.join(figs, "fig_coverage"), extra)
    ex = sorted(glob.glob(os.path.join(inst, "B_R4_S4_mixed_2*.json")))
    if ex:
        fig_map(ex[0], os.path.join(figs, "fig_map"))
    if os.path.exists(EXAMPLE):
        fig_example(EXAMPLE, os.path.join(figs, "fig_example"))
    exname = os.path.basename(ex[0])[:-5] if ex else None
    with open(os.path.join(out, "summary.md"), "w") as f:
        f.write(summary(runs, t2, t3, t4, t5, t6, exname, extra))
    with open(os.path.join(out, "tables.md"), "w") as f:
        f.write(tables_md(t2, t3, t4, t5, t6))
    print("Read %d runs and %d reruns. Wrote 6 tables, 4 figures, summary.md and tables.md to %s"
          % (len(runs), len(extra), out))


if __name__ == "__main__":
    a = sys.argv[1:]
    main(*(a + [RES, INST, OUT][len(a):]))
