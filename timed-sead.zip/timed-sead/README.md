# timed-sead

Data and code for the paper

> **Scheduling and Synchronizing SEAD Missions for Offensive Counterair Attack Operations: Continuous-Time and Time-Indexed Formulations**
> Serhat Saylam, National Defence University, Turkish Air Force Academy, Department of Industrial Engineering.
> Submitted to the Journal of Aeronautics and Space Technologies (2026). The full reference is added here after publication.

The paper schedules suppression of enemy air defences (SEAD) for a given strike plan. Manned SEAD aircraft,
reusable jammer drones and expendable decoy drones open suppression windows at surface-to-air missile (SAM)
sites, and every timed crossing of an engagement zone by a striker must lie inside one window, at least cost.
Two exact formulations are compared, a continuous-time formulation with window slots and a time-indexed
formulation, each with a sortie-selection variant and a hold variant.

## Contents

| Folder | What it holds |
|---|---|
| `code/` | Python modules (gurobipy models, instance generator, independent solution checker, experiment runner, tables and figures) |
| `instances/paperB/` | The 75 test instances of the paper (JSON), mirrored as described below |
| `results/step5/paperB/` | One JSON record per run: 75 instances x 2 formulations x 5 variants = 750 runs, time limit 600 s |
| `results/step5/paperB_3600/` | The four runs that neither formulation solved within 600 s, rerun with the time-indexed formulation and 3600 s |
| `results/paperB/` | `summary.md`, `tables.md`, the CSV tables and the figures of the paper, written by `code/paperB_tables.py` |
| `results/paperB_example.json` | The worked example of Section 2.6, solved with both formulations |

## Code

Python 3.9 or later. The models need Gurobi with `gurobipy` (the paper used Gurobi 12.0.3 with an academic
licence). The tables and figures need only `matplotlib`.

| Module | Purpose |
|---|---|
| `sead_instance.py` | Instance format, arcs and bounds, zone stays of a strike plan |
| `sead_models.py` | `build_paper_B_slot` (continuous-time formulation) and `build_paper_B_ti` (time-indexed formulation), with the options `select` (sortie selection) and `delay` (hold bound in minutes). The module also holds the models of a related integrated routing study |
| `sead_check.py` | `check_solution`, a checker written apart from the models: routes, flight times, endurance, window lengths and the coverage of every zone stay. `snap_solution` reads a solver solution at whole minutes before the check |
| `sead_generator.py` | Seeded instance generator (`paper_B_sets`, `write_sets`, `generate`) |
| `mirror_instances.py` | Mirrors generated instance files in x (see below) |
| `step5_runner.py` | Runs the experiments and saves one JSON record per run (`run_paperB`, `run_paperB_long`, `summarize_paperB`). Runs already saved are skipped |
| `paperB_tables.py` | Builds every table and figure of the paper from the saved runs |
| `paperB_example.py` | Solves and checks the worked example |

Typical use, from the `code` folder:

```
python paperB_tables.py          # tables and figures from the saved runs (no solver needed)
python paperB_example.py         # worked example (Gurobi)
python -c "import step5_runner as R; R.run_paperB()"   # all 750 runs; saved runs are skipped
```

To rerun the experiments from scratch, move the records out of `results/step5/paperB/` first. Each run uses
8 threads, a time limit of 600 s and a relative gap of 0 (`step5_runner.SETTINGS`).

## Instances

Each file `B_R{strikers}_S{sites}_{mix}[-x2|-x3]_{seed}.json` holds one strike plan and its fleet: 2, 4 or 6
strikers with 8, 16 or 24 targets and 3, 4 or 5 SAM sites, three fleet mixes (`mixed`, `drone-rich`,
`manned-rich`) and, for 4 and 6 strikers, a scaled fleet with every count multiplied by 2 (`-x2`) or 3
(`-x3`) on the same plan. The plan (`plan`) gives each striker its targets in order and its launch time, and
`legs` give the flight times and the minutes at which each leg enters and leaves each engagement zone. Times
are whole minutes. Strikers carry the ids S1, S2, ... in the files and R1, R2, ... in the paper.

The generator places the base at the middle of the western edge of a 300 km by 200 km area. The files shared
here were mirrored after generation (`x` replaced by `300 - x`, field `mirrored`), so that the base lies in the
east, as in the figures of the paper. A mirror image keeps every distance, so no flight time, zone stay or
result changes. To regenerate the set, run `sead_generator.write_sets(folder, sead_generator.paper_B_sets())`
and then `python mirror_instances.py folder target_folder`.

## Run records

Each record in `results/step5/paperB/` names the instance, the formulation (`slot` for continuous-time,
`ti` for time-indexed), the variant (`fixed`, `select`, `delay5`, `delay10`, `delay15`), the Gurobi version and
settings, the model size, the status, run time, nodes, objective, bound and gap, the linear relaxation
(`lp`), the solution (windows, assets used, holds) and the verdict of the checker (`check`, `check_ok`).

## Licence

Code: MIT licence (`LICENSE`). Data (instances and results): Creative Commons Attribution 4.0 International
(CC BY 4.0, https://creativecommons.org/licenses/by/4.0/). Please cite the paper when you use them.
