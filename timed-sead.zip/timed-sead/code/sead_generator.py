"""Instance generator for the timed-SEAD papers (step 4).

A seeded 2D theatre: a base on the west edge, targets in the east half, and
circular engagement zones of generic long and short range SAM classes (no named
systems). For every pair of places it computes a direct path, with the entry
and exit time of every zone it crosses, and the shortest path that avoids every
zone not containing an end point. All times are whole minutes (entry rounded
down, exit rounded up, so a stay is never shortened). Suppression assets are of
three generic types. Paper B instances also carry a strike plan, built by a
simple rule that ignores the zones (the planner of the sequential baseline).

    generate(params, seed)        one instance (dict, JSON-ready)
    paper_A_sets(), paper_B_sets() the instance classes decided on 2026-11-23

Changed 2026-11-24 (step 5, decided by Serhat): with params "lead", the strikers launch
at H-hour, the latest arrival of any asset at any station rounded up to 10 min, while
the assets may take off from time 0. H_bar and the target windows are widened by the
lead, and Paper B plans launch at the lead plus a stagger of 0 to 15 min. Paper B has
two fleet levels: the base fleet and the fleet scaled x1, x2, x3 for 2, 4, 6 strikers
(same seed, geometry and plan). The lead and the fleet use no random draws, so the
geometry, targets and routes are the same as in the first version.

Python 3.9 compatible, standard library only (matplotlib only in plot_instance).
"""
import heapq
import json
import math
import os
import random

# ------------------------------------------------------------------ generic parameters
SAM_CLASSES = {                       # radius of the engagement zone in km
    "long": {"radius": 40.0},
    "short": {"radius": 15.0},
}
STRIKER = {"speed": 12.0, "weapons": 2, "endurance": 120}      # km/min (720 km/h)
ASSET_TYPES = {
    # window: minutes a site stays suppressed; cost: per sortie (manned) or per loss (decoy)
    "manned": {"kind": "manned SEAD aircraft", "manned": True, "speed": 12.0, "window": 20,
               "endurance": 150, "cost": 3.0, "expendable": False},
    "jammer": {"kind": "jammer drone", "manned": False, "speed": 3.0, "window": 12,
               "endurance": 300, "cost": 1.0, "expendable": False},
    "decoy": {"kind": "decoy drone", "manned": False, "speed": 4.0, "window": 5,
              "endurance": 120, "cost": 0.5, "expendable": True},
}
STANDOFF = 5.0                        # km outside the zone edge where an asset suppresses
THEATRE = {"width": 300.0, "height": 200.0, "base": (0.0, 100.0),
           "target_x": (140.0, 290.0), "target_y": (20.0, 180.0), "area_x": (80.0, 230.0)}


# ------------------------------------------------------------------ geometry
def _dist(p, q):
    return math.hypot(p[0] - q[0], p[1] - q[1])


def _seg_circle(p, q, c, r):
    """Parameter interval [t0, t1] within [0, 1] where segment p->q is inside circle (c, r), or None."""
    dx, dy = q[0] - p[0], q[1] - p[1]
    fx, fy = p[0] - c[0], p[1] - c[1]
    a = dx * dx + dy * dy
    if a == 0.0:
        return (0.0, 1.0) if fx * fx + fy * fy < r * r else None
    b = 2.0 * (fx * dx + fy * dy)
    cc = fx * fx + fy * fy - r * r
    disc = b * b - 4.0 * a * cc
    if disc <= 0.0:
        return None
    s = math.sqrt(disc)
    t0, t1 = (-b - s) / (2.0 * a), (-b + s) / (2.0 * a)
    t0, t1 = max(t0, 0.0), min(t1, 1.0)
    return (t0, t1) if t1 - t0 > 1e-9 else None


def _blocked(p, q, circles):
    """True if segment p->q passes through the interior of any circle."""
    for (c, r) in circles:
        iv = _seg_circle(p, q, c, r * (1.0 - 1e-6))
        if iv is not None:
            return True
    return False


def _ring(c, r, k=16):
    """Points of a regular k-gon circumscribing the circle, pushed 1% outward."""
    R = r / math.cos(math.pi / k) * 1.01
    return [(c[0] + R * math.cos(2 * math.pi * i / k), c[1] + R * math.sin(2 * math.pi * i / k)) for i in range(k)]


def _shortest_avoiding(p, q, obstacles, cache):
    """Shortest polyline p -> q that avoids the obstacle circles (visibility graph)."""
    key = tuple(sorted(obstacles))
    if key not in cache:
        circles = [o[1] for o in obstacles]
        pts = [pt for (_, (c, r)) in obstacles for pt in _ring(c, r)]
        pts = [pt for pt in pts if all(_dist(pt, c) > r for (c, r) in circles)]
        nbr = {i: [] for i in range(len(pts))}
        for i in range(len(pts)):
            for j in range(i + 1, len(pts)):
                if not _blocked(pts[i], pts[j], circles):
                    d = _dist(pts[i], pts[j])
                    nbr[i].append((j, d))
                    nbr[j].append((i, d))
        cache[key] = (pts, nbr, circles)
    pts, nbr, circles = cache[key]
    if not _blocked(p, q, circles):
        return [p, q]
    n = len(pts)
    S, T = n, n + 1
    adj = {S: [], T: []}
    for i in range(n):
        if not _blocked(p, pts[i], circles):
            adj[S].append((i, _dist(p, pts[i])))
        if not _blocked(pts[i], q, circles):
            adj.setdefault(i, []).append((T, _dist(pts[i], q)))
    dist, prev, heap = {S: 0.0}, {}, [(0.0, S)]
    while heap:
        d, u = heapq.heappop(heap)
        if u == T:
            break
        if d > dist.get(u, float("inf")):
            continue
        nb = adj.get(u, []) + (nbr[u] if u < n else [])
        for v, w in nb:
            if d + w < dist.get(v, float("inf")):
                dist[v], prev[v] = d + w, u
                heapq.heappush(heap, (d + w, v))
    if T not in dist:
        return None
    path, u = [q], T
    while u != S:
        u = prev[u]
        path.append(p if u == S else pts[u])
    return path[::-1]


def _segments_along(path, sites, speed, total_time):
    """Zone segments along a polyline: one (site, entry, exit) per zone, whole minutes."""
    out, s0 = [], 0.0
    lens = [_dist(path[i], path[i + 1]) for i in range(len(path) - 1)]
    iv = {}
    for i in range(len(path) - 1):
        for st in sites:
            x = _seg_circle(path[i], path[i + 1], tuple(st["center"]), st["radius"])
            if x is not None:
                a, b = s0 + x[0] * lens[i], s0 + x[1] * lens[i]
                lo, hi = iv.get(st["id"], (a, b))
                iv[st["id"]] = (min(lo, a), max(hi, b))       # one stay per zone (merged)
        s0 += lens[i]
    for sid, (a, b) in iv.items():
        e = max(0, int(math.floor(a / speed + 1e-9)))
        x = min(total_time, int(math.ceil(b / speed - 1e-9)))
        e = min(e, total_time - 1)              # a stay lasts at least one minute
        if x <= e:
            x = e + 1
        out.append({"site": sid, "entry": e, "exit": x})
    return sorted(out, key=lambda g: g["entry"])


# ------------------------------------------------------------------ generator
def generate(params, seed):
    """One instance. params: n_targets, n_strikers, n_long, n_short, p_point, fleet
    (dict type -> count), and optional name, weapons, endurance, slots, H_bar, mu, plan,
    lead (True: strikers launch at H-hour, see the module note), fleet_scale (label only)."""
    rng = random.Random(seed)
    th = THEATRE
    base = th["base"]
    nT = params["n_targets"]
    # targets, at least 15 km apart
    targets = []
    while len(targets) < nT:
        p = (rng.uniform(*th["target_x"]), rng.uniform(*th["target_y"]))
        if all(_dist(p, q) >= 15.0 for q in targets):
            targets.append(p)
    # sites: point defence (a target inside) or area defence (across the approach)
    sites = []
    classes = ["long"] * params["n_long"] + ["short"] * params["n_short"]
    rng.shuffle(classes)
    for n, cl in enumerate(classes):
        r = SAM_CLASSES[cl]["radius"]
        for _ in range(1000):
            if rng.random() < params["p_point"]:
                tx = targets[rng.randrange(nT)]
                ang, off = rng.uniform(0, 2 * math.pi), rng.uniform(0.0, 0.5 * r)
                c = (tx[0] + off * math.cos(ang), tx[1] + off * math.sin(ang))
            else:
                c = (rng.uniform(*th["area_x"]), rng.uniform(10.0, th["height"] - 10.0))
            if _dist(c, base) > r + 20.0 and all(_dist(c, tuple(s["center"])) > 0.5 * (r + s["radius"]) for s in sites):
                break
        sites.append({"id": "s%d" % (n + 1), "class": cl, "center": [round(c[0], 3), round(c[1], 3)], "radius": r})
    tid = ["T%d" % (i + 1) for i in range(nT)]
    pos = {"B": base}
    pos.update({tid[i]: targets[i] for i in range(nT)})
    for s in sites:
        s["inside"] = [t for t in tid if _dist(pos[t], tuple(s["center"])) < s["radius"]]
    # legs: direct path, and the shortest path avoiding zones that do not contain an end point
    v = STRIKER["speed"]
    cache, legs = {}, []
    places = ["B"] + tid
    for i in range(len(places)):
        for j in range(i + 1, len(places)):
            a, b = places[i], places[j]
            pa, pb = pos[a], pos[b]
            dd = _dist(pa, pb)
            td = max(1, int(round(dd / v)))
            variants = [{"time": td, "segments": _segments_along([pa, pb], sites, v, td)}]
            if variants[0]["segments"]:
                obst = [(s["id"], (tuple(s["center"]), s["radius"])) for s in sites
                        if _dist(pa, tuple(s["center"])) >= s["radius"] and _dist(pb, tuple(s["center"])) >= s["radius"]]
                path = _shortest_avoiding(pa, pb, obst, cache) if obst else None
                if path is not None and len(path) > 2:
                    L = sum(_dist(path[k], path[k + 1]) for k in range(len(path) - 1))
                    tdet = max(1, int(round(L / v)))
                    segs = _segments_along(path, sites, v, tdet)
                    if len(segs) < len(variants[0]["segments"]) and tdet <= 3 * td + 10:
                        variants.append({"time": tdet, "segments": segs,
                                         "path": [[round(x, 6), round(y, 6)] for (x, y) in path]})
            legs.append({"from": a, "to": b, "variants": variants})
    # suppression assets: travel to a station STANDOFF km outside the zone, toward the base
    station = {}
    for s in sites:
        c, r = tuple(s["center"]), s["radius"]
        d = _dist(c, base)
        station[s["id"]] = (c[0] + (base[0] - c[0]) * (r + STANDOFF) / d, c[1] + (base[1] - c[1]) * (r + STANDOFF) / d)
    supp = []
    for typ, cnt in params["fleet"].items():
        T = ASSET_TYPES[typ]
        for n in range(cnt):
            sp = T["speed"]
            t0 = {s["id"]: int(math.ceil(_dist(base, station[s["id"]]) / sp)) for s in sites}
            tss = [[s1["id"], s2["id"], int(math.ceil(_dist(station[s1["id"]], station[s2["id"]]) / sp))]
                   for k, s1 in enumerate(sites) for s2 in sites[k + 1:]]
            supp.append({"id": "%s%d" % (typ[0].upper(), n + 1), "type": typ, "kind": T["kind"], "manned": T["manned"],
                         "window": T["window"], "endurance": T["endurance"], "cost": T["cost"],
                         "expendable": T["expendable"], "sites": [s["id"] for s in sites],
                         "base_to_site": t0, "site_to_base": dict(t0), "site_to_site": tss})
    E = params.get("endurance", STRIKER["endurance"])
    lead = 0
    if params.get("lead"):                # H-hour: every asset can reach every station by then
        lead = int(math.ceil(max(v["base_to_site"][s] for v in supp for s in v["sites"]) / 10.0) * 10)
    HB = params.get("H_bar", E + 30) + lead
    inst = {
        "name": params.get("name", "inst_seed%d" % seed), "seed": seed, "params": params,
        "H_bar": HB, "lead": lead, "mu": params.get("mu", 0.01),
        "slots_per_site": params.get("slots", min(5, params["n_strikers"] + 1)),
        "base": "B", "positions": {k: [round(x, 3), round(y, 3)] for k, (x, y) in pos.items()},
        "strikers": [{"id": "S%d" % (r + 1), "weapons": params.get("weapons", STRIKER["weapons"]), "endurance": E}
                     for r in range(params["n_strikers"])],
        "targets": [{"id": t, "value": rng.randint(5, 15), "weapons": 1, "tw": [0, HB]}
                    for t in tid],
        "sites": sites, "legs": legs, "suppressors": supp,
        "supp_travel": {"base_to_site": {}, "site_to_base": {}, "site_to_site": []},
        "stations": {k: [round(x, 3), round(y, 3)] for k, (x, y) in station.items()},
    }
    if params.get("plan"):
        inst["plan"] = zone_blind_plan(inst, rng)
    return inst


def zone_blind_plan(inst, rng):
    """Strike plan that ignores the zones (Paper B): targets split by bearing from the base
    among the strikers within their weapons, each route ordered by nearest neighbour, always
    the shortest variant (index 0 is the direct path), launches at the lead (H-hour, 0 if
    none) plus a stagger of 0 to 15 min."""
    import sead_instance as SI
    pos = inst["positions"]
    B = pos["B"]
    T = sorted(inst["targets"], key=lambda t: math.atan2(pos[t["id"]][1] - B[1], pos[t["id"]][0] - B[0]))
    R = inst["strikers"]
    cap = [r["weapons"] for r in R]
    groups, k = [[] for _ in R], 0
    for t in T:
        while k < len(R) and len(groups[k]) >= cap[k]:
            k += 1
        if k == len(R):
            break
        groups[k].append(t["id"])
    plan = {}
    for r, g in zip(R, groups):
        rid = r["id"]
        if not g:
            plan[rid] = {"arcs": ["%s:o_%s>d_%s" % (rid, rid, rid)], "launch": inst.get("lead", 0)}
            continue
        order, cur, left = [], "B", list(g)
        while left:
            nxt = min(left, key=lambda t: _dist(tuple(pos[cur]), tuple(pos[t])))
            order.append(nxt)
            left.remove(nxt)
            cur = nxt
        nodes = ["o_" + rid] + order + ["d_" + rid]
        ids = []
        for a, b in zip(nodes[:-1], nodes[1:]):
            if a.startswith("o_"):
                ids.append("%s:%s>%s#0" % (rid, a, b))
            elif b.startswith("d_"):
                ids.append("%s:%s>%s#0" % (rid, a, b))
            else:
                ids.append("%s>%s#0" % (a, b))
        # drop targets from the end while the route exceeds the endurance
        while True:
            pl = SI.plan_from_routes(inst, {rid: ids})
            dur = pl[rid]["times"]["d_" + rid] - pl[rid]["times"]["o_" + rid]
            if dur <= r["endurance"] or len(order) == 0:
                break
            order.pop()
            nodes = ["o_" + rid] + order + ["d_" + rid]
            ids = [("%s:%s>%s#0" % (rid, a, b)) if (a.startswith("o_") or b.startswith("d_")) else ("%s>%s#0" % (a, b))
                   for a, b in zip(nodes[:-1], nodes[1:])]
        plan[rid] = {"arcs": ids, "launch": inst.get("lead", 0) + rng.randint(0, 15)}
    return plan


# ------------------------------------------------------------------ instance classes
FLEETS = {
    "mixed": {"manned": 1, "jammer": 1, "decoy": 1},
    "drone-rich": {"manned": 1, "jammer": 2, "decoy": 3},
    "manned-rich": {"manned": 2, "jammer": 1, "decoy": 1},
}


def paper_A_sets():
    """(class name, params, seeds). Exact set 4 to 10 targets, large set up to 30 for the ALNS."""
    out = []
    exact = [(4, 2, 1, 1), (6, 2, 1, 2), (8, 3, 2, 1), (10, 3, 2, 2)]       # targets, strikers, long, short
    for (nT, nR, nl, ns) in exact:
        for fl, fleet in FLEETS.items():
            name = "A_T%d_R%d_S%d_%s" % (nT, nR, nl + ns, fl)
            out.append((name, {"n_targets": nT, "n_strikers": nR, "n_long": nl, "n_short": ns, "p_point": 0.5,
                               "fleet": fleet, "lead": True}, [1000 + 10 * len(out) + i for i in range(5)]))
    large = [(15, 4, 2, 2), (20, 5, 3, 2), (30, 6, 3, 3)]
    for (nT, nR, nl, ns) in large:
        fleet = {"manned": 2, "jammer": 2, "decoy": 4}
        name = "A_T%d_R%d_S%d_large" % (nT, nR, nl + ns)
        out.append((name, {"n_targets": nT, "n_strikers": nR, "n_long": nl, "n_short": ns, "p_point": 0.5,
                           "fleet": fleet, "weapons": 3, "lead": True}, [1000 + 10 * len(out) + i for i in range(5)]))
    return out


def paper_B_sets():
    """(class name, params, seeds). Plans with 2 to 6 strikers, 3 to 5 sites, strikers
    launching at H-hour. Two fleet levels on the same seeds: the base fleet, and the fleet
    scaled by strikers / 2 (x2 and x3, named ..._mix-x2 and ..._mix-x3). For 2 strikers the
    scaled fleet equals the base fleet, so no separate class is made."""
    out, b = [], 0
    for (nR, nl, ns) in [(2, 1, 2), (4, 2, 2), (6, 2, 3)]:
        for fl, fleet in FLEETS.items():
            seeds = [2000 + 10 * b + i for i in range(5)]
            b += 1
            for k in sorted(set([1, max(1, nR // 2)])):
                name = "B_R%d_S%d_%s" % (nR, nl + ns, fl) + ("" if k == 1 else "-x%d" % k)
                out.append((name, {"n_targets": 4 * nR, "n_strikers": nR, "n_long": nl, "n_short": ns, "p_point": 0.6,
                                   "fleet": dict((t, c * k) for t, c in fleet.items()), "fleet_scale": k,
                                   "weapons": 4, "plan": True, "slots": 8, "lead": True}, seeds))
    return out


def write_sets(folder, sets):
    """Generate and save every instance of the sets, with an index CSV."""
    import sead_instance as SI
    os.makedirs(folder, exist_ok=True)
    rows = ["name,seed,targets,strikers,sites,inside_targets,suppressors,legs_with_detour,stays,lead,H_bar"]
    for (cname, params, seeds) in sets:
        for sd in seeds:
            p = dict(params, name="%s_%d" % (cname, sd))
            inst = generate(p, sd)
            SI.save_instance(inst, os.path.join(folder, inst["name"] + ".json"))
            ins = sum(len(s["inside"]) for s in inst["sites"])
            det = sum(1 for L in inst["legs"] if len(L["variants"]) > 1)
            nst = len(SI.stays_from_plan(inst, SI.plan_from_instance(inst))) if "plan" in inst else ""
            rows.append("%s,%d,%d,%d,%d,%d,%d,%d,%s,%d,%d" % (inst["name"], sd, p["n_targets"], p["n_strikers"],
                        len(inst["sites"]), ins, len(inst["suppressors"]), det, nst, inst["lead"], inst["H_bar"]))
    with open(os.path.join(folder, "index.csv"), "w") as f:
        f.write("\n".join(rows) + "\n")
    return rows


def plot_instance(inst, path=None, show_plan=True):
    """Map of an instance: base, targets, zones, stations, detours, and the plan if any."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7.5, 5))
    for s in inst["sites"]:
        ls = "-" if s["class"] == "long" else "--"
        ax.add_patch(plt.Circle(tuple(s["center"]), s["radius"], fill=True, alpha=0.12, color="#b2182b"))
        ax.add_patch(plt.Circle(tuple(s["center"]), s["radius"], fill=False, ls=ls, color="#b2182b"))
        ax.annotate(s["id"], tuple(s["center"]), ha="center", va="center", fontsize=8, color="#b2182b")
        st = inst["stations"][s["id"]]
        ax.plot(st[0], st[1], marker="^", ms=5, color="#555555")
    P = inst["positions"]
    ax.plot(*P["B"], marker="s", ms=8, color="black")
    ax.annotate("B", tuple(P["B"]), xytext=(4, 4), textcoords="offset points")
    for t in inst["targets"]:
        ax.plot(*P[t["id"]], marker="o", ms=6, color="#2166ac")
        ax.annotate("%s (%d)" % (t["id"], t["value"]), tuple(P[t["id"]]), xytext=(4, 4), textcoords="offset points", fontsize=7)
    if show_plan and "plan" in inst:
        cols = ["#1b9e77", "#d95f02", "#7570b3", "#e7298a", "#66a61e", "#e6ab02"]
        for n, (r, q) in enumerate(inst["plan"].items()):
            pts = []
            for aid in q["arcs"]:
                a, b = aid.split(":")[-1].split("#")[0].split(">")
                a = "B" if a.startswith("o_") else a
                b = "B" if b.startswith("d_") else b
                pts += [P[a], P[b]]
            if pts:
                ax.plot([p[0] for p in pts], [p[1] for p in pts], color=cols[n % len(cols)], lw=1.2, label=r)
        ax.legend(fontsize=7, loc="lower right")
    ax.set_xlim(-10, THEATRE["width"] + 10)
    ax.set_ylim(-10, THEATRE["height"] + 10)
    ax.set_aspect("equal")
    ax.set_xlabel("km")
    ax.set_ylabel("km")
    ax.set_title(inst["name"], fontsize=9)
    fig.tight_layout()
    if path:
        fig.savefig(path, dpi=150)
    plt.close(fig)
