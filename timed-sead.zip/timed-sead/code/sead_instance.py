"""Instance data for the timed-SEAD models (Papers A and B).

An instance is a plain dictionary, saved as JSON in instances/. This module
builds the derived structures the models need (directed arcs per striker,
shortest flight times, earliest and latest times) and holds the worked
scenario of step 1. Python 3.9 compatible, standard library only.

Notation follows model/formulation.tex.
"""
import json
import math

INF = float("inf")


# --------------------------------------------------------------------------- I/O
def save_instance(inst, path):
    with open(path, "w") as f:
        json.dump(inst, f, indent=1)


def load_instance(path):
    with open(path) as f:
        return json.load(f)


# ---------------------------------------------------------------- worked scenario
def scenario_step1():
    """3 targets, 2 SAM sites, 2 strikers, 2 drones (model/step1_problem_statement.md)."""
    leg = lambda a, b, variants: {"from": a, "to": b, "variants": variants}
    var = lambda t, site=None, entry=0, exit_=0: {"time": t, "site": site, "entry": entry, "exit": exit_}
    return {
        "name": "step1_scenario",
        "H_bar": 150, "mu": 0.01, "slots_per_site": 3,
        "base": "B",
        "strikers": [{"id": "S1", "weapons": 2, "endurance": 120},
                     {"id": "S2", "weapons": 2, "endurance": 120}],
        "targets": [{"id": "T1", "value": 10, "weapons": 1, "tw": [0, 150]},
                    {"id": "T2", "value": 8, "weapons": 1, "tw": [0, 150]},
                    {"id": "T3", "value": 6, "weapons": 1, "tw": [0, 150]}],
        "sites": [{"id": "s1", "inside": ["T2"]}, {"id": "s2", "inside": []}],
        # undirected legs; entry and exit are minutes after leaving 'from'
        "legs": [leg("B", "T1", [var(30)]),
                 leg("B", "T2", [var(36, "s1", 30, 36)]),
                 leg("T1", "T2", [var(16, "s1", 10, 16)]),
                 leg("B", "T3", [var(30, "s2", 18, 24), var(55)]),
                 leg("T1", "T3", [var(20, "s2", 7, 13), var(35)]),
                 leg("T2", "T3", [var(25, "s1", 0, 6)])],
        "suppressors": [
            {"id": "D1", "kind": "jammer drone", "manned": False, "window": 15, "endurance": 200,
             "cost": 0, "expendable": False, "sites": ["s1", "s2"]},
            {"id": "D2", "kind": "decoy drone", "manned": False, "window": 6, "endurance": 200,
             "cost": 0, "expendable": True, "sites": ["s1", "s2"]}],
        # flight times of suppressors (all assets unless an asset overrides them)
        "supp_travel": {"base_to_site": {"s1": 25, "s2": 20},
                        "site_to_base": {"s1": 25, "s2": 20},
                        "site_to_site": [["s1", "s2", 15]]},
    }


# ------------------------------------------------------------- derived structures
def _segments(v):
    """Zone segments of a variant: list of (site, entry, exit). A variant stores either
    'segments' (any number of zones, possibly overlapping) or one 'site' with entry and exit."""
    if "segments" in v:
        return [(g["site"], float(g["entry"]), float(g["exit"])) for g in v["segments"]]
    if v.get("site"):
        return [(v["site"], float(v["entry"]), float(v["exit"]))]
    return []


def directed_variants(inst, i, j):
    """Variants of the leg i -> j as (time, segments), mirrored if stored j -> i."""
    for leg in inst["legs"]:
        if leg["from"] == i and leg["to"] == j:
            return [(float(v["time"]), _segments(v)) for v in leg["variants"]]
    for leg in inst["legs"]:
        if leg["from"] == j and leg["to"] == i:
            out = []
            for v in leg["variants"]:
                t = float(v["time"])
                out.append((t, sorted([(s, t - b, t - a) for (s, a, b) in _segments(v)], key=lambda g: g[1])))
            return out
    return []


def build_arcs(inst):
    """Arcs of the multigraph: dict with id, tail, head, time, segs, strikers.

    segs is a list of (site, alpha, beta): the arc is inside the zone of site from alpha
    to beta minutes after leaving its tail (formulation.tex Section 2). Each striker r has
    its own origin o_r and destination d_r. Arcs between targets may be flown by any striker."""
    B = inst["base"]
    R = [r["id"] for r in inst["strikers"]]
    M = [m["id"] for m in inst["targets"]]
    arcs = []

    def add(aid, tail, head, var, strikers):
        t, segs = var
        arcs.append({"id": aid, "tail": tail, "head": head, "time": float(t),
                     "segs": [(s, float(a), float(b)) for (s, a, b) in segs], "strikers": strikers})

    for r in R:
        o, d = "o_" + r, "d_" + r
        add("%s:%s>%s" % (r, o, d), o, d, (0.0, []), [r])
        for m in M:
            for n, v in enumerate(directed_variants(inst, B, m)):
                add("%s:%s>%s#%d" % (r, o, m, n), o, m, v, [r])
            for n, v in enumerate(directed_variants(inst, m, B)):
                add("%s:%s>%s#%d" % (r, m, d, n), m, d, v, [r])
    for m in M:
        for m2 in M:
            if m != m2:
                for n, v in enumerate(directed_variants(inst, m, m2)):
                    add("%s>%s#%d" % (m, m2, n), m, m2, v, list(R))
    return arcs


def shortest_times(inst):
    """Shortest flight time between all places (base and targets) over all variants."""
    P = [inst["base"]] + [m["id"] for m in inst["targets"]]
    d = {(i, j): (0.0 if i == j else INF) for i in P for j in P}
    for i in P:
        for j in P:
            if i != j:
                vs = directed_variants(inst, i, j)
                if vs:
                    d[(i, j)] = float(min(v[0] for v in vs))
    for k in P:
        for i in P:
            for j in P:
                if d[(i, k)] + d[(k, j)] < d[(i, j)]:
                    d[(i, j)] = d[(i, k)] + d[(k, j)]
    return d


def node_bounds(inst):
    """Earliest and latest time of every striker node (formulation.tex Section 6)."""
    sp = shortest_times(inst)
    B, HB = inst["base"], float(inst["H_bar"])
    ES, LS = {}, {}
    for m in inst["targets"]:
        ES[m["id"]] = max(float(m["tw"][0]), sp[(B, m["id"])])
        LS[m["id"]] = min(float(m["tw"][1]), HB - sp[(m["id"], B)])
    for r in inst["strikers"]:
        for n in ("o_" + r["id"], "d_" + r["id"]):
            ES[n], LS[n] = 0.0, HB
    return ES, LS


def inside_sites(inst):
    """Map target -> list of sites whose zones contain it (overlapping zones allowed)."""
    out = {}
    for s in inst["sites"]:
        for m in s["inside"]:
            out.setdefault(m, []).append(s["id"])
    return out


def supp_tau(inst, v):
    """Flight times of suppressor v: (to site, back to base, between sites)."""
    tr = inst.get("supp_travel", {})
    t0 = dict(tr.get("base_to_site", {}))
    tb = dict(tr.get("site_to_base", {}))
    tss = {}
    for a, b, t in tr.get("site_to_site", []) + v.get("site_to_site", []):
        tss[(a, b)] = float(t)
        tss[(b, a)] = float(t)
    t0.update(v.get("base_to_site", {}))
    tb.update(v.get("site_to_base", {}))
    return ({k: float(x) for k, x in t0.items()}, {k: float(x) for k, x in tb.items()}, tss)


def plan_from_routes(inst, routes, launch=None):
    """Plan from arc ids per striker, times by earliest arrival (no holds)."""
    arcs = {a["id"]: a for a in build_arcs(inst)}
    plan = {}
    for r, ids in routes.items():
        seq = [arcs[i] for i in ids]
        t = {seq[0]["tail"]: float((launch or {}).get(r, 0.0))}
        for a in seq:
            t[a["head"]] = t[a["tail"]] + a["time"]
        plan[r] = {"arcs": seq, "times": t}
    return plan


def plan_from_instance(inst):
    """The given strike plan of a Paper B instance (key 'plan')."""
    p = inst["plan"]
    return plan_from_routes(inst, {r: q["arcs"] for r, q in p.items()},
                            {r: q.get("launch", 0.0) for r, q in p.items()})


def slots(inst):
    """Task slots per site: {site: [slot ids]} and {slot: site}."""
    K = {s["id"]: ["%s_k%d" % (s["id"], n) for n in range(int(inst["slots_per_site"]))] for s in inst["sites"]}
    return K, {k: s for s, ks in K.items() for k in ks}


def stays_from_plan(inst, plan):
    """Zone stays of a strike plan (formulation.tex Section 5).

    plan: {striker: {"arcs": [arc dicts in route order], "times": {node: time}}}
    Returns a list of dicts: site, start b, end e, striker, leg index n (index of the
    route node from which the stay's first segment departs). Consecutive segments of
    one striker in the same zone through a target inside that zone form one stay."""
    ins = inside_sites(inst)
    stays = []
    for r, p in plan.items():
        open_ = {}                       # site -> open stay, continued through a target inside its zone
        for n, a in enumerate(p["arcs"]):
            t_dep = p["times"][a["tail"]]
            for (s, al, be) in a["segs"]:
                b, e = t_dep + al, t_dep + be
                if s in open_ and s in ins.get(a["tail"], []):
                    open_[s]["end"] = e  # same stay: entered on the arc in, leaves on this arc
                else:
                    open_[s] = {"site": s, "start": b, "end": e, "striker": r, "leg": n}
                if s not in ins.get(a["head"], []):
                    stays.append(open_.pop(s))   # the striker leaves the zone on this arc
    return sorted(stays, key=lambda h: (h["striker"], h["start"]))


def route_nodes(plan_r):
    """Node sequence of one striker's route, origin first."""
    arcs = plan_r["arcs"]
    return [arcs[0]["tail"]] + [a["head"] for a in arcs]
